<?php
session_start();
require "userConx.php";

if (!isset($_SESSION['userID'])) {
    header("Location: loginForm.php");
    exit;
}

$userID = $_SESSION['userID'];

// Get bookID and payRemBal from the URL
$bookID = isset($_GET['bookID']) ? $_GET['bookID'] : null;
$payRemBal = isset($_GET['payRemBal']) ? $_GET['payRemBal'] : null;
$userEmail = isset($_GET['userEmail']) ? $_GET['userEmail'] : null;
$selectedDate = isset($_GET['selectedDate']) ? $_GET['selectedDate'] : null;
$selectedSlot = isset($_GET['selectedSlot']) ? $_GET['selectedSlot'] : null;

// Ensure bookID and payRemBal are present
if (!$bookID || !$payRemBal) {
    echo "Invalid request.";
    exit;
}

// Fetch the user's phone number
$sqlFetchPhoneNumber = "
SELECT userPhone 
FROM users 
WHERE userID = :userID";

$stmt = $conn->prepare($sqlFetchPhoneNumber);
$stmt->bindParam(':userID', $userID);
$stmt->execute();
$userResult = $stmt->fetch(PDO::FETCH_ASSOC);

if ($userResult) {
    $gcashNumber = $userResult['userPhone'];
} else {
    header("Location: userAppointments.php");
    exit;
}

$minimumPayment = $payRemBal / 2; // Calculate minimum payment (half of payRemBal)
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCash Payment</title>
    <link rel="stylesheet" href="userPayGcash.css">
    <script src="https://kit.fontawesome.com/1fd0899690.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <div id="paymentlogo">
            <img src="images/GCashLogo.png" alt="GCash Logo">
            <h2>GCash Payment</h2>
        </div>

        <form action="payDownCancel.php" method="post">
            <input type="hidden" name="bookID" value="<?php echo $bookID; ?>">
            <a href="#" onclick="this.closest('form').submit();"><i class="fa-solid fa-chevron-left"></i> Return to Appointment Form</a>
        </form>

        <form action="userPayDownSubmit.php" method="post">
            <div class="payment-fields">
                <label for="total_amount">Total Amount Fee:</label><br>
                <input type="text" id="total_amount" value="₱<?php echo number_format($payRemBal, 2); ?>" disabled><br>
                <input type="hidden" name="bookID" value="<?php echo $bookID; ?>">
                <input type="hidden" id="payment_amount" name="payment_amount" value="<?php echo $payRemBal; ?>">
                <input type="hidden" id="userEmail" name="userEmail" value="<?php echo $userEmail; ?>">
                <input type="hidden" id="selectedDate" name="selectedDate" value="<?php echo $selectedDate; ?>">
                <input type="hidden" id="selectedSlot" name="selectedSlot" value="<?php echo $selectedSlot; ?>">
                <label for="actual_payment">Payment Amount:</label><br>
                <input type="number" id="actual_payment" name="actual_payment" required placeholder="Enter amount to pay" min="<?php echo $minimumPayment; ?>" step="0.01"><br>
                <span>Please note that fee is non-refundable. Minimum payment amount is ₱<?php echo number_format($minimumPayment, 2); ?>.</span>
            </div>
            <label for="gcash_number">GCash Number:</label><br>
            <input type="text" id="gcash_number" name="gcash_number" value="<?php echo $gcashNumber; ?>" required><br>
            <button type="submit">Pay via GCash</button>
        </form>
    </div>
</body>
</html>
