<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products Table</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<?php
require 'adminConx.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

$sql = "SELECT * FROM services";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Service ID</th><th>Service Name</th><th>Price</th><th>Duration</th><th>Date Added</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["servID"] . "</td>";
        echo "<td>" . $row["servName"] . "</td>";
        echo "<td>" . $row["servPrice"] . "</td>";
        echo "<td>" . $row["servDuration"] . "</td>";
        echo "<td>" . $row["servDateTime"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>

</body>
</html>