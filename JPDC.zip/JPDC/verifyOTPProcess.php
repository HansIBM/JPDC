<?php
session_start();

if (isset($_POST['otp'])) {
    $enteredOTP = $_POST['otp'];

    // Check if the entered OTP matches the one in the session
    if ($enteredOTP == $_SESSION['otp']) {
        // OTP is correct, proceed with inserting user data into the database
        require 'adminConx.php';

        try {
            $sql = "INSERT INTO users (userID, userFName, userLName, userPass, userEmail, userPhone, userCity, userProvince, userMedConc,userLevel, userDateTime) 
                    VALUES (NULL, :fname, :lname, :hashed_pass, :email, :phone, :city, :prov, :medcon, '2', current_timestamp())";

            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':fname', $_SESSION['fname']);
            $stmt->bindParam(':lname', $_SESSION['lname']);
            $stmt->bindParam(':hashed_pass', $_SESSION['hashed_pass']);
            $stmt->bindParam(':email', $_SESSION['email']);
            $stmt->bindParam(':phone', $_SESSION['phone']);
            $stmt->bindParam(':city', $_SESSION['city']);
            $stmt->bindParam(':prov', $_SESSION['prov']);
            $stmt->bindParam(':medcon', $_SESSION['medcon']);
            $stmt->execute();

            // Registration successful, redirect to login form
            header("Location: loginForm.php");
            exit();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }

        $conn = null;
    } else {
        // OTP is incorrect, set session flag and redirect back to verifyOTP.php
        $_SESSION['otp_error'] = true;
        header("Location: verifyOTP.php");
        exit();
    }
} else {
    // No OTP entered, redirect to verifyOTP.php
    header("Location: verifyOTP.php");
    exit();
}
?>
