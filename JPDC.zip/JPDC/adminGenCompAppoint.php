<?php
// Include TCPDF library
require_once('tcpdf/tcpdf.php');
require('adminConx.php');

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

// Query to retrieve data for completed appointments
$sql = "SELECT b.bookID, u.userFName, u.userLName, s.servName, s.servPrice, b.bookSched, b.bookTime, b.bookCheckIn, b.bookCheckOut, p.payMethod, p.payStatus, p.payDateTime
        FROM booking b
        INNER JOIN users u ON b.userID = u.userID
        INNER JOIN services s ON b.servID = s.servID
        LEFT JOIN payment p ON b.bookID = p.bookID
        WHERE b.bookConfirm = 'Confirmed' AND b.bookStatus = 'Done'
        ORDER BY 
        CASE 
            WHEN RIGHT(b.bookTime, 2) = 'AM' THEN 
                CONCAT('0', LPAD(SUBSTRING_INDEX(b.bookTime, ':', 1), 2, '0'), SUBSTRING_INDEX(b.bookTime, ' ', -1))
            WHEN RIGHT(b.bookTime, 2) = 'PM' AND LEFT(b.bookTime, 2) != '12' THEN 
                CONCAT('1', LPAD(SUBSTRING_INDEX(b.bookTime, ':', 1) + 12, 2, '0'), SUBSTRING_INDEX(b.bookTime, ' ', -1))
            ELSE
                CONCAT('0', LPAD(SUBSTRING_INDEX(b.bookTime, ':', 1), 2, '0'), SUBSTRING_INDEX(b.bookTime, ' ', -1))
        END DESC, 
        b.bookSched DESC";
;
            

$stmt = $conn->query($sql);

// Group appointments by month and day
function groupAppointmentsByMonthAndDay($appointments) {
    $groupedAppointments = [];
    foreach ($appointments as $appointment) {
        $month = date('F Y', strtotime($appointment['bookSched']));
        $day = date('l, F jS', strtotime($appointment['bookSched']));
        if (!isset($groupedAppointments[$month])) {
            $groupedAppointments[$month] = [];
        }
        if (!isset($groupedAppointments[$month][$day])) {
            $groupedAppointments[$month][$day] = [];
        }
        $groupedAppointments[$month][$day][] = $appointment;
    }
    return $groupedAppointments;
}

$groupedAppointments = groupAppointmentsByMonthAndDay($stmt->fetchAll(PDO::FETCH_ASSOC));

// Initialize TCPDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Your Name');
$pdf->SetTitle('Completed Appointments Report');
$pdf->SetSubject('Completed Appointments Report');
$pdf->SetKeywords('TCPDF, PDF, report');

// Remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 10);

// Loop through grouped appointments and output each month and day
// Loop through grouped appointments and output each month and day
foreach ($groupedAppointments as $month => $days) {
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, $month, 0, 1, 'C');
    $totalEarningsMonth = 0; // Initialize total earnings for the month
    foreach ($days as $day => $appointments) {
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 10, $day, 0, 1, 'C');
        // Table header
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->SetFillColor(200, 200, 200); // Set header background color
        $pdf->Cell(12, 10, 'BookID', 1, 0, 'C', true);
        $pdf->Cell(30, 10, 'Name', 1, 0, 'C', true);
        $pdf->Cell(30, 10, 'Service', 1, 0, 'C', true);
        $pdf->Cell(17, 10, 'Price', 1, 0, 'C', true);
        $pdf->Cell(22, 10, 'Schedule', 1, 0, 'C', true);
        $pdf->Cell(17, 10, 'Time', 1, 0, 'C', true);
        $pdf->Cell(17, 10, 'CheckIn', 1, 0, 'C', true); // New cell for check-in time
        $pdf->Cell(17, 10, 'CheckOut', 1, 0, 'C', true); // New cell for check-out time
        $pdf->Cell(30, 10, 'Payment Method', 1, 1, 'C', true);
        // Table data
        $pdf->SetFont('helvetica', '', 10);
        foreach ($appointments as $appointment) {
            $pdf->Cell(12, 10, $appointment["bookID"], 1, 0, 'C');
            $pdf->Cell(30, 10, $appointment["userFName"] . " " . $appointment["userLName"], 1, 0, 'C');
            $pdf->Cell(30, 10, $appointment["servName"], 1, 0, 'C');
            $pdf->Cell(17, 10, $appointment["servPrice"], 1, 0, 'C');
            $pdf->Cell(22, 10, $appointment["bookSched"], 1, 0, 'C');
            $pdf->Cell(17, 10, $appointment["bookTime"], 1, 0, 'C');
            $pdf->Cell(17, 10, $appointment["bookCheckIn"], 1, 0, 'C'); // Cell for check-in time
            $pdf->Cell(17, 10, $appointment["bookCheckOut"], 1, 0, 'C'); // Cell for check-out time
            $pdf->Cell(30, 10, $appointment["payMethod"], 1, 1, 'C');
            $totalEarningsMonth += $appointment['servPrice'];
        }
    }
    // Display total earnings for the month
    $pdf->SetFont('helvetica', 'B', 12);
    $pdf->Cell(0, 10, "Total Earnings for $month: Php" . number_format($totalEarningsMonth, 2), 0, 1, 'C');
    // Add some space between months
    $pdf->Ln(10);
}

// Close and output PDF document
$pdf->Output('completed_appointments_report.pdf', 'D');
