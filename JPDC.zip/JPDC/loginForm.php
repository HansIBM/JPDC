<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Joy Pascual Dental Clinic</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="appointmentstyles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="appointment-container">
        <br>
        <h2 style="text-align: center;">Login</h2>
        <br>
        <form id="login-form" action="loginVerify.php" method="post">
            <label for="email" style="text-align: left;">Email:</label>
            <input type="email" id="email" name="email" required style="width: 325px">

            <label for="password" style="text-align: left;">Password:</label>
            <input type="password" id="password" name="password" required style="width: 325px">
            <br><br>
            <button class="submitbtn" type="submit">Login</button>
        </form>
        
        <br>
        <p style="text-align: center;">Don't have an account yet? 
            <a href="regisForm.php" style="color: #007bff; text-decoration: none;">Register</a>
        </p>

        <button class="rtnbtn" onclick="window.location.href='index.php'">Back</button>
    </div>
</body>
</html>
