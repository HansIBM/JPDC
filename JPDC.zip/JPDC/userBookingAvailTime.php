<?php 
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to index.php
    header("Location: index.php");
    exit();
}

// Include the database connection file
require "userConx.php";

// Check if the date is provided
if (isset($_POST['appointment_date'])) {
    $selectedDate = $_POST['appointment_date'];

    // Get the current date and time
    $currentDate = date('Y-m-d');
    $currentTime = date('H:i');

    // Calculate the time 2 hours from now
    $currentTimePlusTwoHours = date('H:i', strtotime('+2 hours'));

    // All available time slots for the day
    $allSlots = array(
        "09:00 AM",
        "10:00 AM",
        "11:00 AM",
        "12:00 PM",
        "01:00 PM",
        "02:00 PM",
        "03:00 PM",
        "04:00 PM",
        "05:00 PM"
    );

    // Convert time slots to 24-hour format for comparison
    $allSlots24 = array(
        "09:00 AM" => "09:00",
        "10:00 AM" => "10:00",
        "11:00 AM" => "11:00",
        "12:00 PM" => "12:00",
        "01:00 PM" => "13:00",
        "02:00 PM" => "14:00",
        "03:00 PM" => "15:00",
        "04:00 PM" => "16:00",
        "05:00 PM" => "17:00"
    );

    // Query the database to check for booked time slots on the selected date using PDO
    try {
        $bookedSlotsQuery = "
            SELECT bookTime 
            FROM booking 
            WHERE DATE(bookSched) = :selectedDate 
            AND bookSlotAvail = 'Yes'
        ";
        $bookedSlotsStmt = $conn->prepare($bookedSlotsQuery);
        $bookedSlotsStmt->bindParam(':selectedDate', $selectedDate, PDO::PARAM_STR);
        $bookedSlotsStmt->execute();
        $bookedSlots = $bookedSlotsStmt->fetchAll(PDO::FETCH_COLUMN, 0);

        // Filter out booked slots from the list of available slots
        $availableSlots = array_diff($allSlots, $bookedSlots);

        // If the selected date is today, filter out past time slots and time slots within 2 hours
        if ($selectedDate == $currentDate) {
            $availableSlots = array_filter($availableSlots, function($slot) use ($currentTime, $currentTimePlusTwoHours, $allSlots24) {
                // Ensure that the time slot is more than 2 hours ahead
                return $allSlots24[$slot] > $currentTimePlusTwoHours;
            });
        }

        // Return the available slots as JSON
        echo json_encode(array_values($availableSlots));
    } catch (PDOException $e) {
        echo json_encode([]);
    }
} else {
    echo json_encode([]);
}

$conn = null; // Close the PDO connection
?>