<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <title>Register - Joy Pascual Dental Clinic</title>
    <link rel="stylesheet" href="zregisstyles.css">
</head>
<body>
    <div class="appointment-container">
        <h2 style="text-align: center;">Register for an Account</h2>
        <form action="regisSubmit.php" method="post" onsubmit="return validateForm()">
            <div class="form-group">
                <div class="name-group">
                    <div class="first-name-container">
                        <label for="fname">First Name:</label>
                        <input type="text" id="fname" name="fname" value="<?php echo isset($fname) ? $fname : ''; ?>" required pattern="[a-zA-Z\s.]+" title="Only alphabetic characters, spaces, and dots are allowed">
                    </div>
                    <div class="last-name-container">
                        <label for="lname">Last Name:</label>
                        <input type="text" id="lname" name="lname" value="<?php echo isset($lname) ? $lname : ''; ?>" required pattern="[a-zA-Z\s.]+" title="Only alphabetic characters, spaces, and dots are allowed">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" style = "width: 470px" value="<?php echo isset($email) && !isset($emailError) ? $email : ''; ?>" required>
                <span id="emailError" style="color: red;"><?php echo isset($emailError) ? $emailError : ''; ?></span>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" style = "width: 470px" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Password must be at least 8 characters long, containing at least one uppercase letter, one lowercase letter, and one number">
                <span id="passwordError" style="color: red;"><?php echo isset($passwordError) ? $passwordError : ''; ?></span>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" style = "width: 470px" placeholder="(e.g., 09xxxxxxxxx)" value="<?php echo isset($phone) && !isset($phoneError) ? $phone : ''; ?>" required pattern="09\d{9}" title="Phone number must start with '09' followed by 9 digits">
                <span id="phoneError" style="color: red;"><?php echo isset($phoneError) ? $phoneError : ''; ?></span>
            </div>

            <div class="form-group">
                <div class="city-province-group">
                    <div class="city-container">
                        <label for="city">City:</label>
                        <input type="text" id="city" name="city" value="<?php echo isset($city) ? $city : ''; ?>" required pattern="[a-zA-Z\s.]+" title="Only alphabetic characters, spaces, and dots are allowed">
                    </div>
                    <div class="province-container">
                        <label for="prov">Province:</label>
                        <input type="text" id="prov" name="prov" value="<?php echo isset($prov) ? $prov : ''; ?>" required pattern="[a-zA-Z\s.]+" title="Only alphabetic characters, spaces, and dots are allowed">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <div class="med-concern-group">
                    <div class="med-concern">
                        <label for="medcon">Medical Concern: (Leave it blank if none)</label>
                        <input type="text" id="medcon" name="medcon" value="<?php echo isset($medcon) ? $medcon : ''; ?>" placeholder="(e.g., Diabete, Allergies, Recent Heart Surgery, and etc)">
                    </div>
                </div>
            </div>

            <button type="submit">Register</button>
        
        <p class="login-link">Already have an account? 
            <a href="loginform.php" style="color: #007bff; text-decoration: none;">Login</a>
        </p>
    </form>
</div>

        </form>
    </div>
    
    <script>
        function goToLoginForm() {
            window.location.href = "index.php";
        }

        function validateForm() {
            var password = document.getElementById("password").value;
            var passwordError = document.getElementById("passwordError");
            var passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;

            if (!passwordPattern.test(password)) {
                passwordError.textContent = "Password must be at least 8 characters long, containing at least one uppercase letter, one lowercase letter, and one number.";
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
