<?php
$servername = "localhost";
$username = "acclog";
$password = "acclog1234";
$dbname = "jpdc3";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>