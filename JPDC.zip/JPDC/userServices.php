<?php
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

require "adminConx.php";

// Get the userID from the URL
$userID = isset($_GET['userID']) ? $_GET['userID'] : 0;

// Initialize variables
$services = [];
$searchServiceName = '';
$searchServiceDate = '';

// Handle search
if (isset($_GET['search'])) {
    $searchServiceName = isset($_GET['service_name']) ? $_GET['service_name'] : '';
    $searchServiceDate = isset($_GET['service_date']) ? $_GET['service_date'] : '';
}

try {
    // Build the SQL query with search functionality
    $sql = "SELECT * FROM services_done WHERE userID = :userID";
    
    // Add search conditions
    if ($searchServiceName) {
        $sql .= " AND serviceName LIKE :serviceName";
    }
    if ($searchServiceDate) {
        $sql .= " AND serviceDateDone = :serviceDate";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':userID', $userID);

    // Bind search parameters if provided
    if ($searchServiceName) {
        $searchServiceName = "%$searchServiceName%"; // Prepare for LIKE search
        $stmt->bindParam(':serviceName', $searchServiceName);
    }
    if ($searchServiceDate) {
        $stmt->bindParam(':serviceDate', $searchServiceDate);
    }

    $stmt->execute();
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>Error: " . $e->getMessage() . "</p>";
}

$conn = null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Services</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('images/appointmentBG.png');
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        .container {
            max-width: 900px; /* Wider container for better layout */
            margin: 30px auto;
            padding: 20px;
            background-color: #ffffff; /* White background for clarity */
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #4A4A4A; /* Darker title color */
            margin: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 16px; /* Slightly larger font for readability */
        }

        th, td {
            padding: 15px; /* Increased padding for better spacing */
            text-align: center;
        }

        th {
            background-color: #419bc4; /* Primary color for header */
            color: white;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2; /* Lighter shade for even rows */
        }

        tr:hover {
            background-color: #d1e7dd; /* Light highlight on hover */
        }

        .back-button {
            display: inline-block; /* Align button properly */
            margin: 10px auto;
            padding: 12px 25px; /* Adjusted for comfort */
            background-color: #419bc4; /* Consistent button color */
            color: white;
            border: none; /* Removed border for a cleaner look */
            border-radius: 8px; /* Rounded corners */
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 16px; /* Increased font size for readability */
        }

        .back-button:hover {
            background-color: #11566e; /* Darker shade on hover */
        }

        .no-services {
            text-align: center;
            color: #777;
            margin-top: 20px;
        }

        .search-form {
            text-align: center;
            margin-bottom: 20px;
        }

        .search-input {
            padding: 10px;
            font-size: 16px;
            margin-right: 10px;
            border: 1px solid #ccc; /* Border for input fields */
            border-radius: 5px; /* Rounded input corners */
            width: calc(40% - 20px); /* Responsive width */
        }

        .search-button {
            padding: 10px 20px; /* Adjusted padding */
            font-size: 16px; /* Increased font size */
            background-color: #419bc4; /* Button color */
            color: white;
            border: none;
            border-radius: 5px; /* Rounded corners */
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .search-button:hover {
            background-color: #11566e; /* Darker shade on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="adminUserList.php" method="post">
            <input type="submit" value="Back" class="back-button">
        </form>
        <h1>Services Done by User ID: <?php echo htmlspecialchars($userID); ?></h1>

        <!-- Search Form -->
        <form action="" method="get" class="search-form">
            <input type="hidden" name="userID" value="<?php echo htmlspecialchars($userID); ?>">
            <input type="text" name="service_name" class="search-input" placeholder="Service Name" value="<?php echo htmlspecialchars($searchServiceName); ?>">
            <input type="date" name="service_date" class="search-input" placeholder="Service Date" value="<?php echo htmlspecialchars($searchServiceDate); ?>">
            <button type="submit" name="search" class="search-button">Search</button>
        </form>

        <?php if (count($services) > 0) { ?>
            <table>
                <thead>
                    <tr>
                        <th>Service ID</th>
                        <th>Service Name</th>
                        <th>Date Done</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($services as $service) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($service['doneID']); ?></td>
                            <td><?php echo htmlspecialchars($service['serviceName']); ?></td>
                            <td><?php echo htmlspecialchars($service['serviceDateDone']); ?></td>
                            <td><?php echo htmlspecialchars($service['serviceNotes']); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <p class="no-services">No services found for this user.</p>
        <?php } ?>
    </div>
</body>
</html>
