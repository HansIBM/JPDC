<?php
// Include the database connection file
require "adminConx.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirmBooking'])) {
    // Check if the booking ID is provided
    if (isset($_POST['bookID'])) {
        $bookID = $_POST['bookID'];

        try {
            // Begin a transaction
            $conn->beginTransaction();

            // Update the booking status to "Confirmed"
            $updateBookingQuery = "UPDATE booking SET bookConfirm = 'Confirmed', bookSlotAvail = 'No' WHERE bookID = :bookID";
            $stmt = $conn->prepare($updateBookingQuery);
            $stmt->bindParam(':bookID', $bookID, PDO::PARAM_INT);
            $stmt->execute();

            // Get the userID associated with the booking
            $getUserIDQuery = "SELECT userID FROM booking WHERE bookID = :bookID";
            $stmt = $conn->prepare($getUserIDQuery);
            $stmt->bindParam(':bookID', $bookID, PDO::PARAM_INT);
            $stmt->execute();
            $userID = $stmt->fetchColumn();

            // Insert audit trail
            $insertAuditQuery = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, 'Booking Confirmed by Admin', NOW())";
            $stmt = $conn->prepare($insertAuditQuery);
            $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
            $stmt->execute();

            // Commit the transaction
            $conn->commit();

            // Redirect back to the booking list page after updating
            header("Location: adminBookingList.php");
            exit();
        } catch (PDOException $e) {
            // Roll back the transaction if an exception occurs
            $conn->rollBack();
            // Display error message if an exception occurs
            echo "Error updating booking status: " . $e->getMessage();
        }
    } else {
        echo "Booking ID is required.";
    }
}

// Close the database connection
$conn = null;
?>
