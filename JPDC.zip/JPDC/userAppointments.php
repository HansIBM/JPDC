<?php
session_start();
require "userConx.php";

if (!isset($_SESSION['userID'])) {
    header("Location: loginForm.php");
    exit;
}

$userID = $_SESSION['userID'];

try {
    // Fetch Pending Appointments
    $sqlFetchPendingAppointments = "
        SELECT 
            b.bookID, 
            CONCAT(u.userFName, ' ', u.userLName) AS fullName,
            s.servName, 
            s.servPrice, 
            b.bookSched, 
            b.bookTime, 
            b.bookConfirm, 
            b.bookStatus, 
            COALESCE(p.payRemBal, s.servPrice) AS payRemBal,
            p.payDownRef, 
            p.payMethod, 
            p.payStatus
        FROM booking b
        JOIN services s ON b.servID = s.servID
        LEFT JOIN payment p ON b.bookID = p.bookID
        INNER JOIN users u ON b.userID = u.userID
        WHERE b.userID = :userID
        AND (b.bookConfirm = 'Confirmed' AND b.bookStatus = 'Not Done') OR b.bookStatus = 'Waiting for Cancellation'
        ORDER BY b.bookSched DESC, b.bookTime DESC";

    
    $stmtPending = $conn->prepare($sqlFetchPendingAppointments);
    $stmtPending->bindParam(':userID', $userID);
    $stmtPending->execute();
    $pendingAppointments = $stmtPending->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Past Appointments
    $sqlFetchPastAppointments = "
        SELECT 
            b.bookID, 
            s.servName, 
            s.servPrice, 
            b.bookSched, 
            b.bookTime, 
            b.bookStatus,
            p.payDownRef, 
            p.payFullRef,
            p.payMethod, 
            p.payDateTime
        FROM booking b
        JOIN services s ON b.servID = s.servID
        LEFT JOIN payment p ON b.bookID = p.bookID
        WHERE b.userID = :userID
        AND b.bookStatus = 'Done'
        ORDER BY b.bookID DESC, b.bookTime DESC";


    
    $stmtPast = $conn->prepare($sqlFetchPastAppointments);
    $stmtPast->bindParam(':userID', $userID);
    $stmtPast->execute();
    $pastAppointments = $stmtPast->fetchAll(PDO::FETCH_ASSOC);

    $userEmailQuery = "SELECT userEmail FROM users WHERE userID = :userID";
    $userEmailStmt = $conn->prepare($userEmailQuery);
    $userEmailStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
    $userEmailStmt->execute();
    $userEmailResult = $userEmailStmt->fetch(PDO::FETCH_ASSOC);

    // Check if user email is retrieved
    if ($userEmailResult) {
        $userEmail = $userEmailResult['userEmail'];
    } else {
        throw new Exception("User email not found.");
    }

} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;

function groupAppointmentsByMonthAndDay($appointments) {
    $groupedAppointments = [];
    foreach ($appointments as $appointment) {
        $month = date('F Y', strtotime($appointment['bookSched']));
        $day = date('l, F jS', strtotime($appointment['bookSched']));
        if (!isset($groupedAppointments[$month])) {
            $groupedAppointments[$month] = [];
        }
        if (!isset($groupedAppointments[$month][$day])) {
            $groupedAppointments[$month][$day] = [];
        }
        $groupedAppointments[$month][$day][] = $appointment;
    }
    return $groupedAppointments;
}

$groupedPendingAppointments = groupAppointmentsByMonthAndDay($pendingAppointments);
$groupedPastAppointments = groupAppointmentsByMonthAndDay($pastAppointments);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Appointments</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            background-image: url('images/regisBG.avif'); /* Replace 'background_image.jpg' with the path to your image */
            background-size: cover; /* Cover the entire body */
            background-position: center; /* Center the background image */
        }

        .container {
            max-width: 1300px;
            margin: 30px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            text-align: center;
            color: #333;
            margin: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #000;
            color: white;
            font-weight: normal;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .toggle-button, .back-button, .gcash-button, .cancel-button, .vAppInfo {
            display: block;
            width: fit-content;
            margin: 10px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .toggle-button:hover, .back-button:hover, .gcash-button:hover, .cancel-button:hover , .vAppInfo:hover {
            background-color: #0056b3;
        }

        .cancel-button {
            background-color: #dc3545;
        }

        .cancel-button:hover {
            background-color: #c82333;
        }

        .hidden {
            display: none;
        }

        .month-group {
            margin-top: 30px;
        }

        .month-title {
            font-size: 24px;
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 20px 0 10px;
            color: #0056b3;
            text-align: center;
        }

        .day-title {
            font-size: 18px;
            margin: 10px 0;
            color: #555;
            text-align: center;
        }

        form {
            display: inline;
        }
                /* The Modal */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 999; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0, 0, 0, 0.6); /* Black with transparency */
        }

        /* Modal Content/Box */
        .modal-content {
            background-color: #f9f9f9;
            margin: 10% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 400px;
            border-radius: 8px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }

        /* Additional styles for the modal content */
        .modal-header,
        .modal-footer {
            padding: 10px 0; /* Add some padding to header and footer */
            text-align: center;
            border-bottom: 1px solid #eee; /* Bottom border */
        }

        .modal-body {
            padding: 20px 0; /* Add padding to body */
        }
        p{
            color: gray;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="userPage.php" class="back-button">Back to Profile</a>
        <h1>Your Appointments</h1>
        <button class="toggle-button" onclick="toggleAppointments()">View Past Appointments</button>
        
        <div id="pending-appointments">
            <h2>Current Appointments</h2>
            <?php if (count($groupedPendingAppointments) > 0) {
                foreach ($groupedPendingAppointments as $month => $days) { ?>
                    <div class="month-group">
                        <div class="month-title"><?php echo $month; ?></div>
                        <?php foreach ($days as $day => $appointments) { ?>
                            <div class="day-title"><?php echo $day; ?></div>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Book ID</th>
                                        <th>Service Name</th>
                                        <th>Service Price</th>
                                        <th>Schedule</th>
                                        <th>Time</th>
                                        <th>Remaining Balance</th>
                                        <th>Down Reference</th>
                                        <th>Payment Method</th>
                                        <th>Payment Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($appointments as $appointment) { ?>
                                        <tr>
                                            <td><?php echo $appointment['bookID']; ?></td>
                                            <td><?php echo $appointment['servName']; ?></td>
                                            <td><?php echo $appointment['servPrice']; ?></td>
                                            <td><?php echo $appointment['bookSched']; ?></td>
                                            <td><?php echo $appointment['bookTime']; ?></td>
                                            <td><?php echo number_format($appointment['payRemBal'], 2); ?></td>
                                            <td><?php echo $appointment['payDownRef'] !== null ? $appointment['payDownRef'] : 'N/A'; ?></td>
                                            <td><?php echo $appointment['payMethod']; ?></td>
                                            <td><?php echo $appointment['payStatus']; ?></td>
                                            <td>
                                                <a href="userPayGcash.php?bookID=<?php echo $appointment['bookID']; ?>&payRemBal=<?php echo $appointment['payRemBal']; ?>&userEmail=<?php echo $userEmail?>" class="gcash-button">Pay with GCash</a>
                                                <button class="vAppInfo" 
                                                    data-book-id="<?php echo $appointment['bookID']; ?>"
                                                    data-serv-name="<?php echo $appointment['servName']; ?>"
                                                    data-serv-price="<?php echo $appointment['servPrice']; ?>"
                                                    data-book-sched="<?php echo $appointment['bookSched']; ?>"
                                                    data-book-time="<?php echo $appointment['bookTime']; ?>"
                                                    data-book-status="<?php echo $appointment['bookStatus']; ?>"
                                                    data-full-name="<?php echo $appointment['fullName']; ?>">View Appointment Info</button>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>

                            </table>
                        <?php } ?>
                    </div>
                <?php }
            } else { ?>
                <p>No pending appointments found.</p>
            <?php } ?>
        </div>

        <div id="past-appointments" class="hidden">
            <h2>Past Appointments</h2>
            <?php if (count($groupedPastAppointments) > 0) {
                foreach ($groupedPastAppointments as $month => $days) { ?>
                    <div class="month-group">
                        <div class="month-title"><?php echo $month; ?></div>
                        <?php foreach ($days as $day => $appointments) { ?>
                            <div class="day-title"><?php echo $day; ?></div>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Book ID</th>
                                        <th>Service Name</th>
                                        <th>Service Price</th>
                                        <th>Schedule</th>
                                        <th>Time</th>
                                        <th>Down Reference</th>
                                        <th>Full Reference</th>
                                        <th>Payment Method</th>
                                        <th>Payment Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($appointments as $appointment) { ?>
                                        <tr>
                                            <td><?php echo $appointment['bookID']; ?></td>
                                            <td><?php echo $appointment['servName']; ?></td>
                                            <td><?php echo $appointment['servPrice']; ?></td>
                                            <td><?php echo $appointment['bookSched']; ?></td>
                                            <td><?php echo $appointment['bookTime']; ?></td>
                                            <td><?php echo $appointment['payDownRef'] !== null ? $appointment['payDownRef'] : ''; ?></td>
                                            <td><?php echo $appointment['payFullRef'] !== null ? $appointment['payFullRef'] : 'CASH'; ?></td>
                                            <td><?php echo $appointment['payMethod']; ?></td>
                                            <td><?php echo $appointment['payDateTime']; ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>

                            </table>
                        <?php } ?>
                    </div>
                <?php }
            } else { ?>
                <p>No past appointments found.</p>
            <?php } ?>
        </div>
    </div>
    <div id="myModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Appointment Information</h2>
            <p class="verification-message">*Show this for verification*</p>
            <table id="appointmentInfoTable">
                <!-- Booking information will be dynamically inserted here -->
            </table>
        </div>
    </div>

    <script>
        function toggleAppointments() {
            const pendingAppointments = document.getElementById('pending-appointments');
            const pastAppointments = document.getElementById('past-appointments');
            const toggleButton = document.querySelector('.toggle-button');

            if (pendingAppointments.classList.contains('hidden')) {
                pendingAppointments.classList.remove('hidden');
                pastAppointments.classList.add('hidden');
                toggleButton.textContent = 'View Past Appointments';
            } else {
                pendingAppointments.classList.add('hidden');
                pastAppointments.classList.remove('hidden');
                toggleButton.textContent = 'View Pending Appointments';
            }
        }

        // Function to open the modal and display appointment information
        function openModal(bookingInfo) {
            const modal = document.getElementById('myModal');
            const modalContent = modal.querySelector('.modal-content');
            const appointmentInfoTable = document.getElementById('appointmentInfoTable');
            
            // Clear any existing data in the table
            appointmentInfoTable.innerHTML = '';

            // Populate the table with booking information
            for (const [key, value] of Object.entries(bookingInfo)) {
                const row = document.createElement('tr');
                const cell1 = document.createElement('td');
                const cell2 = document.createElement('td');

                cell1.textContent = key;
                cell2.textContent = value;

                row.appendChild(cell1);
                row.appendChild(cell2);

                appointmentInfoTable.appendChild(row);
            }

            // Display the modal
            modal.style.display = 'block';
        }

        // Function to close the modal
        function closeModal() {
            const modal = document.getElementById('myModal');
            modal.style.display = 'none';
        }

        // Add event listeners to the "View Appointment Info" buttons
        const viewAppInfoButtons = document.querySelectorAll('.vAppInfo');
        viewAppInfoButtons.forEach(button => {
            button.addEventListener('click', function() {
                const bookingInfo = {
                    'Booking ID': button.dataset.bookId,
                    'Full Name': button.dataset.fullName,
                    'Service Name': button.dataset.servName,
                    'Service Price': button.dataset.servPrice,
                    'Schedule': button.dataset.bookSched,
                    'Time': button.dataset.bookTime,
                    'Status': button.dataset.bookStatus
                    // Add more booking information as needed
                };
                openModal(bookingInfo);
            });
        });
    </script>
</body>
</html>
