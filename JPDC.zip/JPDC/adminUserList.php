<?php
session_start();
require "adminConx.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
        header("Location: loginForm.php");
        exit();
    }

    // Initialize search variables
    $searchColumn = '';
    $searchValue = '';

    // Handle search
    if (isset($_GET['search'])) {
        $searchColumn = $_GET['search'];
        $searchValue = $_GET['search_value'];
    }

    // Default sorting column
    $sortColumn = isset($_GET['sort']) ? $_GET['sort'] : 'userID';

    // Build the SQL query
    try {
        $sql = "SELECT * FROM users WHERE userLevel = '2'";
        
        // Add search conditions
        if ($searchColumn && $searchValue) {
            $sql .= " AND $searchColumn LIKE :searchValue";
        }

        // Add sorting
        $sql .= " ORDER BY $sortColumn ASC";

        $stmt = $conn->prepare($sql);
        
        // Bind the search value if provided
        if ($searchColumn && $searchValue) {
            $stmt->bindValue(':searchValue', "%$searchValue%");
        }

        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "<p>Error: " . $e->getMessage() . "</p>";
    }


    if (isset($_POST['logout'])) {
        // Destroy the session
        session_destroy();

        // Redirect to login form
        header("Location: index.php");
        exit;
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Services</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            height: 100vh;
            width: 250px;
            background-color: #419bc4;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 16px;
            text-decoration: none;
            text-align: left;
            font-size: 18px;
            position: relative; /* To position the ::before element */
        }

        .sidebar a:hover {
            background-color: #11566e;
        }

        .sidebar a.active {
            background-color: #11566e;
        }

        /* White rectangle for active menu item */
        .sidebar a.active::before {
            content: '';
            position: absolute;
            left: -15px; /* Adjust as needed */
            top: 0;
            bottom: 0;
            width: 10px; /* Width of the rectangle */
            background-color: white; /* Color of the rectangle */
            border-radius: 5px; /* Optional: rounded corners */
        }

        .content {
            margin-left: 250px; /* Same as the sidebar width */
            padding: 30px 40px; /* Increased padding for better spacing */
            background-color: #f5f5f5; /* Subtle background color */
            min-height: 100vh; /* Ensure it fills the entire height */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Slightly larger shadow for more depth */
            border-radius: 10px; /* Rounded corners */
        }

        .content h1, .content h2 {
            color: #333;
            margin-bottom: 20px;
            font-family: 'Arial', sans-serif;
        }

        .add-button {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 10px 20px;
            width: 400px;
            margin-bottom: 30px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .add-button:hover {
            background-color: #11566e;
        }

        .center {
            text-align: center;
        }


        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            border-radius: 8px;
            overflow: hidden; /* To apply border-radius to the table */
        }

        table th, table td {
            padding: 12px; /* Increased padding for better spacing */
            border: 1px solid #ddd;
            text-align: left;
            background-color: #f9f9f9; /* Light background color for table rows */
        }

        table th {
            background-color: #419bc4; /* Header background color */
            color: white; /* Header text color */
            font-weight: bold;
            text-align: center; /* Center align headers */
        }

        table tbody tr:nth-child(even) {
            background-color: #f2f2f2; /* Alternate row coloring */
        }

        table tbody tr:hover {
            background-color: #e6f7ff; /* Row hover effect */
            cursor: pointer; /* Pointer cursor on hover */
        }

        /* Search and Sort Forms */
            .sort-form, .search-form {
                margin-bottom: 20px;
                display: inline-block;
            }

            .sort-select, .search-select, .search-input, .search-button {
                padding: 8px 12px;
                border: 1px solid #ccc;
                border-radius: 5px;
                font-size: 14px;
                margin-right: 10px;
            }

            .sort-select, .search-select {
                background-color: #fff;
            }

            .search-input {
                width: 200px;
            }

            .search-button {
                background-color: #419bc4;
                color: white;
                border: none;
                cursor: pointer;
                transition: background-color 0.3s;
            }

            .search-button:hover {
                background-color: #11566e;
            }

            /* Action Buttons */
            .view-services-button {
                background-color: #419bc4;
                color: white;
                border: none;
                padding: 6px 12px;
                text-decoration: none;
                border-radius: 5px;
                transition: background-color 0.3s;
                font-size: 14px;
            }

            .view-services-button:hover {
                background-color: #11566e;
            }

            /* For inline forms (like in Actions column) */
            .action-buttons {
                display: inline-block;
            }

            .action-buttons form {
                display: inline-block;
                margin-right: 5px;
            }

            .action-buttons input {
                background-color: #419bc4;
                color: white;
                border: none;
                padding: 6px 12px;
                cursor: pointer;
                border-radius: 5px;
                transition: background-color 0.3s;
            }

            .action-buttons input:hover {
                background-color: #11566e;
            }



        .logout-btn input {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 50px;
            height: 50px;
            width: 250px;
            transition: background-color 0.3s;
        }

        .logout-btn input:hover {
            background-color: #11566e;
        }

        /* Modal CSS */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 100px;
        }

        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
        }

        .modal-content h2 {
            color: #333;
            margin-bottom: 10px;
        }

        .modal-content h3 {
            color: #555;
        }

        .modal-content p a {
            color: #419bc4;
            text-decoration: underline;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }


        .profile-section {
            display: flex;
            align-items: center;
            padding: 20px;
            color: white;
        }

        .profile-section img {
            border-radius: 50%;
            width: 60px;
            height: 60px;
            margin-right: 10px;
        }

        .profile-section div {
            line-height: 1.5;
        }

        .profile-section div span {
            display: block;
        }

        .profile-section div span.email {
            font-size: 10px;
        }

        .logo {
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            width: 200px; /* Adjust as needed */
        }
        button {
            background-color: transparent; /* No background color */
            color: white; /* Text color */
            border: 2px solid white; /* White outline */
            cursor: pointer; /* Pointer cursor on hover */
            font-size: 16px; /* Font size */
            border-radius: 8px; /* Optional: rounded corners */
            transition: background-color 0.3s, color 0.3s; /* Smooth transition */
        }

        button:hover {
            background-color: white; /* Background color on hover */
            color: #419bc4; /* Change text color on hover */
        }
    </style>
</head>
<body>
    <?php

        $userID = $_SESSION['userID'];

        $sqlFetch = "SELECT * FROM users WHERE userID = :userID";
        $stmt = $conn->prepare($sqlFetch);
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>

    <div class="sidebar">
        <div class="profile-section">
            <img src="images/default_pic.png" alt="Admin Profile">
            <div>
                <?php if ($row) { ?>
                    <span><strong><?php echo htmlspecialchars($row['userFName'] . " " . $row['userLName']); ?></strong></span>
                    <span class="email"><?php echo htmlspecialchars($row['userEmail']); ?></span>
                <?php } ?>
            </div>
        </div>
        <a href="adminPage.php" >Dashboard</a>
        <a href="adminAppointList.php">Appointments</a>
        <a href="adminServices.php">Services</a>
        <a href="adminUserList.php" class="active">User Profiles</a>
        <a href="adminAuditTrail.php">User Activity</a>
        <?php if ($row) { ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="logout-btn">
                    <input type="submit" name="logout" value="Logout">
                </form>
        <?php } ?>

        <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic" class="logo">
    </div>

    <div class="content">
 
        <div class="container">
            <h1>Patients</h1>

            <!-- Sort Form -->
            <form action="" method="get" class="sort-form">
                <label for="sort">Sort by:</label>
                <select name="sort" id="sort" class="sort-select" onchange="this.form.submit()">
                    <option value="userID" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'userID') echo 'selected'; ?>>User ID</option>
                    <option value="userFName" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'userFName') echo 'selected'; ?>>First Name</option>
                    <option value="userLName" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'userLName') echo 'selected'; ?>>Last Name</option>
                    <option value="userCity" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'userCity') echo 'selected'; ?>>City</option>
                    <option value="userProvince" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'userProvince') echo 'selected'; ?>>Province</option>
                </select>
            </form>

            <!-- Search Form -->
            <form action="" method="get" class="search-form">
                <label for="search">Search by:</label>
                <select name="search" id="search" class="search-select">
                    <option value="userID" <?php if ($searchColumn == 'userID') echo 'selected'; ?>>User ID</option>
                    <option value="userFName" <?php if ($searchColumn == 'userFName') echo 'selected'; ?>>First Name</option>
                    <option value="userLName" <?php if ($searchColumn == 'userLName') echo 'selected'; ?>>Last Name</option>
                    <option value="userCity" <?php if ($searchColumn == 'userCity') echo 'selected'; ?>>City</option>
                </select>
                <input type="text" name="search_value" class="search-input" value="<?php echo htmlspecialchars($searchValue); ?>">
                <button type="submit" class="search-button">Search</button>
            </form>

            <?php if (count($users) > 0) { ?>
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>City</th>
                            <th>Province</th>
                            <th>Registered Date & Time</th>
                            <th>Actions</th> <!-- New Column for Actions -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['userID']); ?></td>
                                <td><?php echo htmlspecialchars($user['userFName']); ?></td>
                                <td><?php echo htmlspecialchars($user['userLName']); ?></td>
                                <td><?php echo htmlspecialchars($user['userEmail']); ?></td>
                                <td><?php echo htmlspecialchars($user['userPhone']); ?></td>
                                <td><?php echo htmlspecialchars($user['userCity']); ?></td>
                                <td><?php echo htmlspecialchars($user['userProvince']); ?></td>
                                <td><?php echo htmlspecialchars($user['userDateTime']); ?></td>
                                <td>
                                    <a href="userServices.php?userID=<?php echo htmlspecialchars($user['userID']); ?>" class="view-services-button">View Services</a>
                                </td> <!-- Button to view services -->
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p class="no-users">No users found.</p>
            <?php } ?>
        </div>
    </div>

    <script>

    </script>
</body>
</html>