<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to index.php
    header("Location: index.php");
    exit();
}

// Include the database connection file
require "userConx.php";

// Get the current date and date one year later
$startDate = date('Y-m-d');
$endDate = date('Y-m-d', strtotime('+1 year'));

// All available time slots
$allSlots = array(
    "09:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "01:00 PM",
    "02:00 PM",
    "03:00 PM",
    "04:00 PM",
    "05:00 PM"
);

// Query to get booked slots and dates
try {
    $query = "
        SELECT DATE(bookSched) AS date, bookTime
        FROM booking
        WHERE DATE(bookSched) BETWEEN :startDate AND :endDate
        AND bookSlotAvail = 'No'
    ";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':startDate', $startDate, PDO::PARAM_STR);
    $stmt->bindParam(':endDate', $endDate, PDO::PARAM_STR);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Group results by date
    $bookedDates = [];
    foreach ($results as $row) {
        $bookedDates[$row['date']][] = $row['bookTime'];
    }

    // Filter dates to ensure at least one slot is available
    $availableDates = [];
    for ($date = strtotime($startDate); $date <= strtotime($endDate); $date = strtotime("+1 day", $date)) {
        $currentDate = date('Y-m-d', $date);
        if (!isset($bookedDates[$currentDate]) || count($bookedDates[$currentDate]) < count($allSlots)) {
            $availableDates[] = ['availableDate' => $currentDate];
        }
    }

    // Return available dates as JSON
    echo json_encode($availableDates);
} catch (PDOException $e) {
    echo json_encode([]);
}

$conn = null; // Close the PDO connection
?>
