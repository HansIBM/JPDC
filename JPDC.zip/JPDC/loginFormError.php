<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body>
    <div class="header">
        <div class="logo-container">
            <img src="images/Logo.png" alt="Logo" class="logo">
        </div>
        <h1>Joy Pascual Dental Clinic</h1>
    </div>
    
    <div class="container">
        <form action="loginVerify.php" method="post">
            <h2>Login</h2>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>
        <form action="regisForm.php">
            <div class="form-group">
                <button type="submit">Register</button>
            </div>
        </form>
         <label id="check">The username or password does not exist!</label>
    </div>
</body>
</html>
