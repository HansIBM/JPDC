<?php
session_start();
require "adminConx.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

if (isset($_POST['logout'])) {
    // Destroy the session
    session_destroy();

    // Redirect to login form
    header("Location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Appointment List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            height: 100vh;
            width: 250px;
            background-color: #419bc4;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 16px;
            text-decoration: none;
            text-align: left;
            font-size: 18px;
            position: relative; /* To position the ::before element */
        }

        .sidebar a:hover {
            background-color: #11566e;
        }

        .sidebar a.active {
            background-color: #11566e;
        }

        /* White rectangle for active menu item */
        .sidebar a.active::before {
            content: '';
            position: absolute;
            left: -15px; /* Adjust as needed */
            top: 0;
            bottom: 0;
            width: 10px; /* Width of the rectangle */
            background-color: white; /* Color of the rectangle */
            border-radius: 5px; /* Optional: rounded corners */
        }

        .content {
            margin-left: 120px;
            padding: 20px;
            background-color: #f9f9f9; /* Slightly lighter background */
            min-height: 100vh;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            color: #333; /* Text color */
            font-size: 16px; /* General font size for the content */
        }

        .content h1, .content h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .container h1, h2 {
            border-bottom: 2px solid #419bc4; /* Add an underline to headings */
            padding-bottom: 10px;
            font-weight: bold;
        }

        button.toggle-button {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            margin-bottom: 20px;
            transition: background-color 0.3s;
        }

        button.toggle-button:hover {
            background-color: #11566e;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: #fff; /* White background for the table */
            border-radius: 5px; /* Rounded corners for the table */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        table th, table td {
            padding: 12px;
            border: 1px solid #ddd; /* Light gray borders */
            text-align: left;
        }

        table th {
            background-color: #419bc4;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        table tr:nth-child(even) {
            background-color: #f2f2f2; /* Alternating row color */
        }

        table tr:hover {
            background-color: #e0f0f8; /* Row highlight on hover */
        }

        .day-title {
            font-weight: bold;
            font-size: 18px;
            color: #11566e;
            margin-top: 20px;
        }

        .month-title {
            font-size: 22px;
            font-weight: bold;
            color: #419bc4;
            margin-top: 30px;
            padding-bottom: 10px;
        }

        .month-earnings {
            margin-top: 10px;
            font-weight: bold;
            color: #333;
        }

        .mark-as-paid-button, .edit-button {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .mark-as-paid-button:hover, .edit-button:hover {
            background-color: #11566e;
        }


        .logout-btn input {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 50px;
            height: 50px;
            width: 250px;
            transition: background-color 0.3s;
        }

        .logout-btn input:hover {
            background-color: #11566e;
        }

        /* Modal CSS */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 100px;
        }

        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
        }

        .modal-content h2 {
            color: #333;
            margin-bottom: 10px;
        }

        .modal-content h3 {
            color: #555;
        }

        .modal-content p a {
            color: #419bc4;
            text-decoration: underline;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }


        .profile-section {
            display: flex;
            align-items: center;
            padding: 20px;
            color: white;
        }

        .profile-section img {
            border-radius: 50%;
            width: 60px;
            height: 60px;
            margin-right: 10px;
        }

        .profile-section div {
            line-height: 1.5;
        }

        .profile-section div span {
            display: block;
        }

        .profile-section div span.email {
            font-size: 10px;
        }

        .logo {
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            width: 200px; /* Adjust as needed */
        }
        button {
            background-color: transparent; /* No background color */
            color: white; /* Text color */
            border: 2px solid white; /* White outline */
            cursor: pointer; /* Pointer cursor on hover */
            font-size: 16px; /* Font size */
            border-radius: 8px; /* Optional: rounded corners */
            transition: background-color 0.3s, color 0.3s; /* Smooth transition */
        }

        button:hover {
            background-color: white; /* Background color on hover */
            color: #419bc4; /* Change text color on hover */
        }

        .hidden {
            display: none;
        }

        /* Style for the search bar container */
        input#searchBar {
            width: 90%; /* Full width */
            padding: 10px; /* Padding inside the search bar */
            margin-bottom: 20px; /* Space below the search bar */
            border: 1px solid #ccc; /* Light gray border */
            border-radius: 5px; /* Rounded corners */
            font-size: 16px; /* Font size */
            transition: border-color 0.3s; /* Transition effect for border color */
        }

        /* Style for the search bar on focus */
        input#searchBar:focus {
            border-color: #007bff; /* Change border color on focus */
            outline: none; /* Remove default outline */
        }

        /* Responsive design for smaller screens */
        @media (max-width: 600px) {
            input#searchBar {
                font-size: 14px; /* Smaller font size for mobile */
                padding: 8px; /* Reduced padding for mobile */
            }
        }

    </style>
</head>
<body>
    <?php
        $userID = $_SESSION['userID'];

        $sqlFetch = "SELECT * FROM users WHERE userID = :userID";
        $stmt = $conn->prepare($sqlFetch);
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>

    <div class="sidebar">
        <div class="profile-section">
            <img src="images/default_pic.png" alt="Admin Profile">
            <div>
                <?php if ($row) { ?>
                    <span><strong><?php echo htmlspecialchars($row['userFName'] . " " . $row['userLName']); ?></strong></span>
                    <span class="email"><?php echo htmlspecialchars($row['userEmail']); ?></span>
                <?php } ?>
            </div>
        </div>
        <a href="adminPage.php">Dashboard</a>
        <a href="adminAppointList.php" class="active">Appointments</a>
        <a href="adminServices.php">Services</a>
        <a href="adminUserList.php">User Profiles</a>
        <a href="adminAuditTrail.php">User Activity</a>
        <?php if ($row) { ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="logout-btn">
                    <input type="submit" name="logout" value="Logout">
                </form>
        <?php } ?>

        <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic" class="logo">
    </div>

    <div class="content">
 
    <div class="content">
        <div class="container">
            <h1>Appointment</h1>
            <button class="toggle-button" onclick="toggleAppointments()">Completed Appointments</button>

            <input type="text" id="searchBar" onkeyup="filterAppointments()" placeholder="Search by Name, Service, or Booking ID">

            <?php
            try {
                // Fetch Pending Appointments
                $sqlPending = "
                SELECT b.bookID, CONCAT(u.userFName, ' ', u.userLName) AS fullName, 
                    s.servName, s.servPrice, b.bookSched, b.bookTime, 
                    b.bookCheckIn, b.bookCheckOut, 
                    p.payRemBal, p.payDownRef, p.payFullRef, p.payMethod
                FROM booking b
                INNER JOIN users u ON b.userID = u.userID
                INNER JOIN services s ON b.servID = s.servID
                LEFT JOIN payment p ON b.bookID = p.bookID
                WHERE b.bookConfirm = 'Confirmed' AND (b.bookStatus = 'Not Done' OR b.bookStatus = 'Waiting For Cancellation')
                ORDER BY 
                CASE 
                    WHEN RIGHT(b.bookTime, 2) = 'AM' THEN 
                        CONCAT('0', LPAD(SUBSTRING_INDEX(b.bookTime, ':', 1), 2, '0'), SUBSTRING_INDEX(b.bookTime, ' ', -1))
                    WHEN RIGHT(b.bookTime, 2) = 'PM' AND LEFT(b.bookTime, 2) != '12' THEN 
                        CONCAT('1', LPAD(SUBSTRING_INDEX(b.bookTime, ':', 1) + 12, 2, '0'), SUBSTRING_INDEX(b.bookTime, ' ', -1))
                    ELSE
                        CONCAT('0', LPAD(SUBSTRING_INDEX(b.bookTime, ':', 1), 2, '0'), SUBSTRING_INDEX(b.bookTime, ' ', -1))
                END DESC, 
                b.bookSched DESC";


            
            $stmtPending = $conn->prepare($sqlPending);
            $stmtPending->execute();
            $pendingAppointments = $stmtPending->fetchAll(PDO::FETCH_ASSOC);

                // Fetch Completed Appointments with Paid Status
                $sqlCompleted = "
                SELECT b.bookID, CONCAT(u.userFName, ' ', u.userLName) AS fullName, 
                    s.servName, s.servPrice, b.bookSched, b.bookTime, 
                    b.bookCheckIn, b.bookCheckOut, 
                    p.payRemBal, p.payDownRef, p.payFullRef, p.payMethod, p.payStatus
                FROM booking b
                INNER JOIN users u ON b.userID = u.userID
                INNER JOIN services s ON b.servID = s.servID
                LEFT JOIN payment p ON b.bookID = p.bookID
                WHERE b.bookConfirm = 'Confirmed' AND b.bookStatus = 'Done' AND p.payStatus = 'Paid'
                ORDER BY b.bookSched DESC, b.bookTime DESC";

                $stmtCompleted = $conn->prepare($sqlCompleted);
                $stmtCompleted->execute();
                $completedAppointments = $stmtCompleted->fetchAll(PDO::FETCH_ASSOC);

                $totalEarningsAll = 0;
                foreach ($completedAppointments as $appointment) {
                $totalEarningsAll += $appointment['servPrice'];
                }

            } catch (PDOException $e) {
                echo "<p>Error: " . $e->getMessage() . "</p>";
            }

            $conn = null;
            ?>

            <div id="pending-appointments">
                <h2>Pending Appointments</h2>
                <?php if (count($pendingAppointments) > 0) { ?>
                    <table id="pendingTable">
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Name</th>
                                <th>Service</th>
                                <th>Price</th>
                                <th>Schedule</th>
                                <th>Time</th>
                                <th>Time Check In</th>
                                <th>Time Check Out</th>
                                <th>Remaining Balance</th>
                                <th>Down Reference</th>
                                <th>Full Reference</th>
                                <th>Payment Method</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pendingAppointments as $appointment) { ?>
                                <tr>
                                    <td><?php echo $appointment['bookID']; ?></td>
                                    <td><?php echo $appointment['fullName']; ?></td>
                                    <td><?php echo $appointment['servName']; ?></td>
                                    <td><?php echo $appointment['servPrice']; ?></td>
                                    <td><?php echo $appointment['bookSched']; ?></td>
                                    <td><?php echo $appointment['bookTime']; ?></td>
                                    <td><?php echo $appointment['bookCheckIn'] != null ? date("g:i A", strtotime($appointment['bookCheckIn'])) : ''; ?></td>
                                    <td><?php echo $appointment['bookCheckOut'] != null ? date("g:i A", strtotime($appointment['bookCheckOut'])) : ''; ?></td>
                                    <td><?php echo $appointment['payRemBal'] !== null ? $appointment['payRemBal'] : '0.00'; ?></td>
                                    <td><?php echo $appointment['payDownRef'] !== '0' ? $appointment['payDownRef'] : 'CASH'; ?></td>
                                    <td><?php echo $appointment['payFullRef'] !== '0' ? $appointment['payFullRef'] : 'CASH'; ?></td>
                                    <td><?php echo $appointment['payMethod'] !== null ? $appointment['payMethod'] : 'CASH'; ?></td>
                                    <td>
                                        <form action="adminMarkAsPaid.php" method="post">
                                            <input type="hidden" name="bookID" value="<?php echo $appointment['bookID']; ?>">
                                            <input type="submit" name="markAsPaid" value="Mark as Paid By Cash" class="mark-as-paid-button">
                                        </form><br>
                                        <button class="edit-button" onclick="populateModal('<?php echo $appointment['bookID']; ?>', '<?php echo $appointment['bookCheckIn']; ?>', '<?php echo $appointment['bookCheckOut']; ?>')">Edit CheckIn/Out</button>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                <?php } else { ?>
                    <p>No pending appointments found.</p>
                <?php } ?>
            </div>

            <div id="completed-appointments" class="hidden">
                <h2>Completed Appointments</h2>
                <h2>Total Earnings: <?php echo '₱' . number_format($totalEarningsAll, 2); ?></h2>
                <?php if (count($completedAppointments) > 0) { ?>
                    <table id="completedTable">
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Name</th>
                                <th>Service</th>
                                <th>Price</th>
                                <th>Schedule</th>
                                <th>Time</th>
                                <th>Time Check In</th>
                                <th>Time Check Out</th>
                                <th>Remaining Balance</th>
                                <th>Down Reference</th>
                                <th>Full Reference</th>
                                <th>Payment Method</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($completedAppointments as $appointment) { ?>
                                <tr>
                                    <td><?php echo $appointment['bookID']; ?></td>
                                    <td><?php echo $appointment['fullName']; ?></td>
                                    <td><?php echo $appointment['servName']; ?></td>
                                    <td><?php echo $appointment['servPrice']; ?></td>
                                    <td><?php echo $appointment['bookSched']; ?></td>
                                    <td><?php echo $appointment['bookTime']; ?></td>
                                    <td><?php echo $appointment['bookCheckIn'] != null ? date("g:i A", strtotime($appointment['bookCheckIn'])) : ''; ?></td>
                                    <td><?php echo $appointment['bookCheckOut'] != null ? date("g:i A", strtotime($appointment['bookCheckOut'])) : ''; ?></td>
                                    <td><?php echo $appointment['payRemBal'] !== null ? $appointment['payRemBal'] : '0.00'; ?></td>
                                    <td><?php echo $appointment['payDownRef'] !== '0' ? $appointment['payDownRef'] : 'CASH'; ?></td>
                                    <td><?php echo $appointment['payFullRef'] !== '0' ? $appointment['payFullRef'] : 'CASH'; ?></td>
                                    <td><?php echo $appointment['payMethod'] !== null ? $appointment['payMethod'] : 'CASH'; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                <?php } else { ?>
                    <p>No completed appointments found.</p>
                <?php } ?>
            </div>
        </div>
    </div>

    <div id="myModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2>Edit Appointment</h2>
                <form id="editForm" action="adminEditCheckTime.php" method="POST">
                    <input type="hidden" id="bookID">
                    <label for="checkInTime">Check-in Time:</label>
                    <input type="time" id="checkInTime" name="checkInTime">
                    <label for="checkOutTime">Check-out Time:</label>
                    <input type="time" id="checkOutTime" name="checkOutTime">
                    <input type="submit" value="Submit" onclick="submitForm()">
                </form>
            </div>
        </div>
    </div>

    <script>
        function toggleAppointments() {
            var pendingDiv = document.getElementById('pending-appointments');
            var completedDiv = document.getElementById('completed-appointments');
            var toggleButton = document.querySelector('.toggle-button');

            if (pendingDiv.classList.contains('hidden')) {
                pendingDiv.classList.remove('hidden');
                completedDiv.classList.add('hidden');
                toggleButton.textContent = 'Completed Appointments';
                // Remove the "Download PDF" button if it exists
            } else {
                pendingDiv.classList.add('hidden');
                completedDiv.classList.remove('hidden');
                toggleButton.textContent = 'Pending Appointments';
                // Add the "Download PDF" button
            }
        }

        function filterAppointments() {
            var input = document.getElementById("searchBar");
            var filter = input.value.toLowerCase();
            var tables = document.querySelectorAll("table");
            tables.forEach(function(table) {
                var rows = table.getElementsByTagName("tr");
                for (var i = 1; i < rows.length; i++) {
                    var cells = rows[i].getElementsByTagName("td");
                    var rowContainsFilter = false;
                    for (var j = 0; j < cells.length; j++) {
                        if (cells[j]) {
                            if (cells[j].innerText.toLowerCase().indexOf(filter) > -1) {
                                rowContainsFilter = true;
                                break;
                            }
                        }
                    }
                    rows[i].style.display = rowContainsFilter ? "" : "none";
                }
            });
        }


        function openModal() {
            document.getElementById("myModal").style.display = "block";
        }

        function closeModal() {
            document.getElementById("myModal").style.display = "none";
        }

        // JavaScript function to populate the modal with row data
        function populateModal(bookID, checkInTime, checkOutTime) {
            document.getElementById("bookID").value = bookID;
            document.getElementById("checkInTime").value = checkInTime;
            document.getElementById("checkOutTime").value = checkOutTime;
            openModal();
        }

        // JavaScript function to submit the edited data to the server
        function submitForm() {
            var bookID = document.getElementById("bookID").value;
            var checkInTime = document.getElementById("checkInTime").value;
            var checkOutTime = document.getElementById("checkOutTime").value;

            // Create a FormData object
            var formData = new FormData();
            formData.append("bookID", bookID);
            formData.append("checkInTime", checkInTime);
            formData.append("checkOutTime", checkOutTime);

            // Submit the form data using Fetch API
            fetch('adminEditCheckTime.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Handle response from server
                if (data.success) {
                    closeModal();
                    // Optionally, update the table data without reloading the page
                } else {
                    // Handle errors
                    console.error('Error:', data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }


    </script>
</body>
</html>