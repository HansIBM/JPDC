<?php require('adminConx.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Report</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h1 class="mt-5 mb-4">Booking Report</h1>
    <p>Report generated on <?php echo date('Y-m-d'); ?></p>
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
        <tr><th>Book ID</th><th>User Name</th><th>Services</th><th>Status</th><th>Date Booked</th></tr>
        </thead>
    <tbody>
    <?php

    // Check if the user is logged in and is an admin
    if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
        header("Location: loginForm.php");
        exit();
    }
    // Pagination
        $limit = 3; // Number of records per page
        $page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number

    // Calculate offset for pagination
        $offset = ($page - 1) * $limit;

    // Query to retrieve data from the "sam" table with pagination
    $sql = "SELECT b.bookID,
                u.userFName, u.userLName,
                GROUP_CONCAT(s.servName SEPARATOR '<br>') AS serv_names,
                b.bookConfirm,
                b.bookDateTime,
                t.slotSched
            FROM booking b 
            INNER JOIN users u ON b.userID = u.userID
            INNER JOIN services s ON b.servID = s.servID
            INNER JOIN timeslot t ON b.slotID = t.slotID
            GROUP BY b.groupID
            ORDER BY b.bookDateTime ASC
            LIMIT :limit OFFSET :offset";

        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

    // Fetch data
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Initialize variables
        $currentMonth = '';

        // Loop through the results
        foreach ($rows as $row) {
            $regDate = date('F Y', strtotime($row['slotSched']));
            // Check if a new month is encountered
            if ($currentMonth != $regDate) {
                $currentMonth = $regDate;
                echo '<tr><td colspan="4"><strong>' . $currentMonth . '</strong></td></tr>';
            }
            // Add data for each record
            echo '<tr>';
            echo "<td>" . $row["bookID"] . "</td>";
            echo "<td>" . $row["userFName"] . " " . $row["userLName"] . "</td>";
            echo "<td>" . $row["serv_names"] . "</td>";
            echo "<td>" . $row["bookConfirm"] . "</td>";
            // Format date and time
            $bookDateTime = date("Y-m-d H:i:s", strtotime($row["bookDateTime"]));
            echo "<td>" . $bookDateTime . "</td>";
            echo '</tr>';
        }

    ?>

    </tbody>
    </table>
    <!-- Add pagination links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
           <li class="page-item <?php echo ($page <= 1 ? 'disabled' : ''); ?>">
              <a class="page-link" href="?page=<?php echo ($page - 1); ?>" tabindex="-1">Previous</a>
           </li>
           <li class="page-item">
              <a class="page-link" href="?page=<?php echo ($page + 1); ?>">Next</a>
           </li>
        </ul>
    </nav>

    <!-- Add buttons for PDF conversion -->
    <div class="mt-3">
       <a href="gen_pdf.php" target="_blank" class="btn btn-primary">Download PDF</a>
    </div>
</div>
</body>
</html>

<?php
// Close the database connection
$conn = null;
?>
