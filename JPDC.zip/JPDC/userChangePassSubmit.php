<?php
require "userConx.php";
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to index.php
    header("Location: index.php");
    exit();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $oldPassword = $_POST["current-password"];
    $newPassword = $_POST["new-password"];
    $confirmNewPassword = $_POST["confirm-new-password"];
    
    // Retrieve user's current password hash from the database based on the user ID
    $userId = $_SESSION["userID"];
    $query = "SELECT userPass FROM users WHERE userID = :userId";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':userId', $userId);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $storedPasswordHash = $row["userPass"];
    
    // Verify old password
    if (password_verify($oldPassword, $storedPasswordHash)) {
        // Validate new password
        if ($newPassword === $confirmNewPassword) {
            // Hash the new password
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            
            // Update the user's password in the database
            $updateQuery = "UPDATE users SET userPass = :newPasswordHash WHERE userID = :userId";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bindParam(':newPasswordHash', $newPasswordHash);
            $stmt->bindParam(':userId', $userId);
            $stmt->execute();
            
            // Add audit trail for password change
            $auditAction = "Password Change";
            $auditDateTime = date("Y-m-d H:i:s");
            $insertAuditQuery = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userId, :auditAction, :auditDateTime)";
            $stmt = $conn->prepare($insertAuditQuery);
            $stmt->bindParam(':userId', $userId);
            $stmt->bindParam(':auditAction', $auditAction);
            $stmt->bindParam(':auditDateTime', $auditDateTime);
            $stmt->execute();
            
            // Set success message
            $_SESSION["errorType"] = "success"; // Set success type
            header("Location: userPage.php");
            exit();
        } else {
            // Set error type if new passwords don't match
            $_SESSION["errorType"] = "passwordMismatch"; // Set error type
        }
    } else {
        // Set error type if old password is incorrect
        $_SESSION["errorType"] = "incorrectPassword"; // Set error type
    }
    
    // Redirect back to the change password page with error type
    header("Location: userPage.php");
    exit();
}
?>
