<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to index.php
    header("Location: index.php");
    exit();
}

$userID = $_SESSION['userID'];
$bookID = $_GET['bookID'];
$servName = $_GET['servName'];
$servPrice = $_GET['servPrice'];


// Include the database connection file
require "userConx.php";

// Fetch services from the database using PDO
try {
    $sql = "SELECT servID, servName, servPrice FROM services";  // Fetch price too
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error executing query: " . $e->getMessage());
}

// Get the current date in the format YYYY-MM-DD
$currentDate = date('Y-m-d');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reschedule Appointment</title>
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
<link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
<link rel="stylesheet" href="appointmentstyles2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css' rel='stylesheet' />

<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js'></script>



<script>
document.addEventListener('DOMContentLoaded', function() {
    const timeSlot = document.getElementById('time_slot');
    const bookForm = document.getElementById('bookForm');
    const confirmModal = document.getElementById('confirmModal');
    const confirmBtn = document.getElementById('confirmBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    const closeModal = document.getElementById('closeModal');
    const closeMessageModal = document.getElementById('closeMessageModal');
    const calendar = $('#calendar');

    // Initialize FullCalendar
    calendar.fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'JPDC'
        },
        editable: true,
        validRange: {
            start: moment().startOf('day').format('YYYY-MM-DD'),
            end: moment().add(5, 'months').endOf('day').format('YYYY-MM-DD')
        },
        viewRender: function(view, element) {
            const start = view.intervalStart.format('YYYY-MM-DD');
            const end = view.intervalEnd.format('YYYY-MM-DD');
            loadMonthAvailability(start, end);
        },
        dayClick: function(date, jsEvent, view) {
            const selectedDate = date.format();
            const isFullyBooked = $(jsEvent.target).hasClass('fully-booked');

            // Remove previously selected date
            $('.fc-day.selected-date').removeClass('selected-date');

            if (isFullyBooked) {
                alert('This date is fully booked. Please select another date.');
                return;
            }

            // Add selected class to the clicked date
            $(jsEvent.target).addClass('selected-date');

            $('#appointment_date').val(selectedDate);
            $('#time_slot').empty().append('<option value="">Select Time</option>');
            fetchAvailableSlots(selectedDate);
        },
        eventRender: function(event, element) {
            if (event.className.includes('fully-booked')) {
                $(element).css('background-color', '#f00'); // Red background
                $(element).css('color', '#fff'); // White text color
                $(element).css('cursor', 'not-allowed'); // Not-allowed cursor
            } else if (event.className.includes('available-date')) {
                $(element).css('background-color', '#0f0'); // Green background
                $(element).css('color', '#000'); // Black text color
            }
        }
    });

    function loadMonthAvailability(startDate, endDate) {
        $.ajax({
            url: 'userBookingAvailDates.php',
            type: 'POST',
            data: { start_date: startDate, end_date: endDate },
            dataType: 'json',
            success: function(data) {
                $('.fc-day').removeClass('available-date fully-booked');

                const dateRequests = data.map(dateObj => {
                    const date = dateObj.availableDate;
                    return $.ajax({
                        url: 'userBookingAvailTime.php',
                        type: 'POST',
                        data: { appointment_date: date },
                        dataType: 'json',
                        success: function(slots) {
                            if (slots.length === 0) {
                                $(`.fc-day[data-date="${date}"]`).addClass('fully-booked');
                            } else {
                                $(`.fc-day[data-date="${date}"]`).addClass('available-date');
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error fetching time slots:', error);
                        }
                    });
                });

                $.when.apply($, dateRequests).done(function() {
                    console.log('All date data loaded');
                });
            },
            error: function(xhr, status, error) {
                console.error('Error fetching dates:', error);
            }
        });
    }

    function fetchAvailableSlots(date) {
        $.ajax({
            url: 'userBookingAvailTime.php',
            type: 'POST',
            data: { appointment_date: date },
            dataType: 'json',
            success: function(slots) {
                timeSlot.innerHTML = '<option value="">Select Time</option>';
                if (Array.isArray(slots)) {
                    slots.forEach(slot => {
                        const option = document.createElement('option');
                        option.value = slot;
                        option.textContent = slot;
                        timeSlot.appendChild(option);
                    });
                } else {
                    console.error('Data received is not an array:', slots);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching time slots:', error);
            }
        });
    }

    bookForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const date = document.getElementById('appointment_date').value;
        const time = document.getElementById('time_slot').value;
        document.getElementById('modalDate').innerText = date;
        document.getElementById('modalTime').innerText = time;
        confirmModal.style.display = 'block';
    });

    confirmBtn.addEventListener('click', function() {
        confirmModal.style.display = 'none';
        document.getElementById('bookingMessageModal').style.display = 'block';
        setTimeout(function() {
            bookForm.submit();
        }, 2000);
    });

    cancelBtn.addEventListener('click', function() {
        confirmModal.style.display = 'none';
    });

    closeModal.addEventListener('click', function() {
        confirmModal.style.display = 'none';
    });

    closeMessageModal.addEventListener('click', function() {
        document.getElementById('bookingMessageModal').style.display = 'none';
    });
});


</script>
</head>
<body>
    <div class="appointment-container">
        <h2>Reschedule Appointment</h2>   
        <h5>*Rescheduling can be done up to 2 days before the scheduled appointment.</h5>  
        <form id="bookForm" action="userReschedSubmit.php" method="post">
            <input type="hidden" name="bookID" value="<?php echo $bookID; ?>">
            <label for="service">Service:</label>
            <input type="text" id="service" name="service" value="<?php echo htmlspecialchars($servName); ?>" required readonly>
                
            <!-- Price Display -->
            <div id="priceDisplay">Price: ₱<?php echo number_format($servPrice, 2); ?></div>

            <label for="date">Date Selected:</label>
            <input type="text" id="appointment_date" name="appointment_date" readonly required style = "width: 325px">

            <label for="time">Appointment Time</label>
            <select id="time_slot" name="time_slot" required>
                <option value="">Select Time</option >
            </select>
            <!-- Submit button -->
            <button type="submit" class="submitbtn">Reschedule Appointment</button>
        </form>
        
        <form action="userPage.php" method="post">
            <button type="submit" class="rtnbtn">Return Home</button>
        </form>
    </div>

    <!-- Calendar -->
    <div id="calendar"></div>

    <!-- Confirm Modal -->
    <div id="confirmModal" class="modal">
        <div class="modal-content">
            <span id="closeModal" class="close">&times;</span>
            <div class="modal-header">Reschedule Booking</div>
            <div class="modal-body">
                <p>Date: <span id="modalDate"></span></p>
                <p>Time: <span id="modalTime"></span></p>
            </div>
            <div class="modal-footer">
                <button id="confirmBtn" class="confirm-btn">Confirm</button>
                <button id="cancelBtn" class="cancel-btn">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Booking Message Modal -->
    <div id="bookingMessageModal" class="modal">
        <div class="modal-content">
            <span id="closeMessageModal" class="close">&times;</span>
            <div class="modal-body">Reschedule Submitted</div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const serviceDropdown = document.getElementById('service');
        const priceDisplay = document.getElementById('priceDisplay');

        serviceDropdown.addEventListener('change', function() {
            const selectedServiceID = this.value;

            if (selectedServiceID) {
                // Make an AJAX request to get the price
                fetch('getServicePrice.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `serviceID=${encodeURIComponent(selectedServiceID)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.price !== null) {
                        priceDisplay.textContent = `Price: ₱${parseFloat(data.price).toFixed(2)}`;
                    } else {
                        priceDisplay.textContent = `Price: ₱0.00`;
                    }
                })
                .catch(error => {
                    console.error('Error fetching service price:', error);
                    priceDisplay.textContent = `Price: ₱0.00`;
                });
            } else {
                priceDisplay.textContent = `Price: ₱0.00`;
            }
        });
    });
    </script>
</body>
</html>

<?php
$conn = null; // Close the PDO connection
?>
