<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
    <link rel="stylesheet" href="appointmentstyles.css">
    <!-- <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            min-height: 100vh;
            background-image: url('images/loginbg.jpg');
            background-size: cover;
            background-position: center;
        }

        .header {
            position: absolute;
            top: 20px;
            left: 20px;
            display: flex;
            align-items: center;
        }

        .logo-container {
            margin-right: 10px;
        }

        .logo {
            width: 250px;
            height: auto;
        }

        h1 {
            font-family: 'Brush Script MT', cursive;
            font-size: 72px;
            font-weight: normal;
            margin: 0;
        }

        .container {
            width: 20%;
            height: 50vh;
            margin: 0 20px;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"] {
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            display: none;
        }
    </style> -->
    <style>
        .error-message {
            color: red;
            display: none;
        }
        .appointment-container {
            text-align: center;
            background-color: #fff; /* White background for the rectangle */
            border-radius: 15px; /* Rounded corners */
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            padding: 20px; /* Space inside the container */
            width: 300px; /* Fixed width */
            height: 300px;
        }
        input {
    color: #11566e;
    width: 90%; /* Full width for inputs */
    padding: 10px; /* Padding inside inputs */
    margin-bottom: 10px; /* Space below inputs */
    border: 2px solid #ccc; /* Border style */
    border-radius: 5px; /* Rounded corners for inputs */
}
    </style>
    <script>
        // Function to display error message
        function displayErrorMessage() {
            document.getElementById('otp-error').style.display = 'block';
        }
    </script>
</head>
<body>
    <div class="header">
        <div class="logo-container">
            <img src="images/Logo.png" alt="Logo" class="logo">
        </div>
    </div>
    
    <div class="appointment-container">
        <form action="verifyOTPProcess.php" method="post">
            <h2>Verify OTP</h2>
            <div class="form-group">
                <label for="otp">Enter OTP:</label>
                <input type="text" id="otp" name="otp" required>
                <div class="error-message" id="otp-error">Invalid OTP. Please try again.</div>
            </div>
            <div class="form-group">
                <button class="submitbtn" name= "subbtn" type="submit">Submit OTP</button>
            </div>
        </form>
    </div>
    <?php
        // Check if OTP error occurred and display error message
        if(isset($_SESSION['otp_error']) && $_SESSION['otp_error'] === true) {
            echo '<script>displayErrorMessage();</script>';
            unset($_SESSION['otp_error']); // Reset error flag
        }
    ?>
</body>
</html>
