<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Appointments</title>
<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }
</style>
</head>
<body>
<?php
// Include database connection
require 'adminConx.php';

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare SQL statement with placeholders to prevent SQL injection
$sql = "SELECT a.appointID,
               CONCAT(u.userFName, ' ', u.userLName) AS userFullName,
               GROUP_CONCAT(s.servName SEPARATOR '<br>') AS serv_names,
               a.appointTotalAmount,
               a.appointTotalDuration,
               a.appointStatus,
               a.appointDateTime
        FROM appointment a
        INNER JOIN booking b ON a.bookID = b.bookID
        INNER JOIN users u ON b.userID = u.userID
        INNER JOIN services s ON b.servID = s.servID
        GROUP BY a.groupID";

$result = $conn->query($sql);

if ($result) {
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Appointment ID</th><th>User Name</th><th>Services</th><th>Total Amount</th><th>Duration</th><th>Status</th><th>Date Booked</th></tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["appointID"] . "</td>";
            echo "<td>" . $row["userFullName"] . "</td>";
            echo "<td>" . $row["serv_names"] . "</td>";
            echo "<td>" . $row["appointTotalAmount"] . "</td>";
            echo "<td>" . $row["appointTotalDuration"] . "</td>";
            echo "<td>" . $row["appointStatus"] . "</td>";
            // Format date and time
            $appointDateTime = date("Y-m-d H:i:s", strtotime($row["appointDateTime"]));
            echo "<td>" . $appointDateTime . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No appointments found";
    }
} else {
    // Error handling for query execution
    echo "Error: " . $conn->error;
}

// Close connection
$conn->close();
?>
</body>
</html>
