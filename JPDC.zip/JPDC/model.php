<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Joy Pascual Dental Clinic</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="style-model.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>

</head>
<body>
    <header>
        <!-- COPY PASTE LAGI TO KASI SAME LANG NAV LINKS-->
        <div class="header-container">
            <div class="logo">
                <img src="images/ToothJPDC.png" alt="Joy Pascual Dental Clinic">
            </div>
            <nav>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="index.php#about">About</a></li>
                    <li class="dropdown">
                        <a href="javascript:void(0)" class="dropbtn">Services <i class ="fas fa-chevron-down" style = "font-size: 12px; margin-left:5px"></i></a>
                        <div class="dropdown-content">
                            <a href="model.php">Teeth Model</a>
                            <a href="guest_service1.php">Esthetic Dentistry</a>
                            <a href="guest_service2.php">Prosthodontic Treatment</a>
                            <a href="guest_service3.php">Orthodontic Treatment</a>
                            <a href="guest_service4.php">Teeth Extraction</a>
                        </div>
                    </li>
                    <li><a href="loginForm.php">Account</a></li>
                </ul>
            </nav>
            <a href="userBooking.php" class="appointment-btn">Book an Appointment</a>
        </div>
    </header>

    <div id="model-description">
        <img src="images/information.png" alt="Info Icon">
        <span>Hold and drag the 3D Model to Interact</span>
    </div>
    
      <div id="model-history-container">
        <div id="model-container"></div>
    </div>


    <!-- Service Buttons -->    
    <div id="service-buttons">
        <button data-model="images/default_new.glb">Reset</button>
        <button data-model="images/braces.glb">Braces</button>
        <button data-model="images/teeth_yellow.glb">Teeth Whitening</button>
        <button data-model="images/missing_teeth.glb">Dentures</button>
        <button data-model="images/extraction.glb">Extraction</button>
    </div>

    <footer>
        <div class="footer-container">
            <div class="footer-column">
                <h3>Useful Links</h3>
                <a href="#">Home</a>
                <a href="#">About</a>
                <a href="#">Services</a>
            </div>
            <div class="footer-column">
                <h3>Contact Us</h3>
                <a href="#">Contact Form</a>
                <a href="#">FAQ</a>
            </div>
            <div class="footer-column newsletter">
                <h3>Newsletter</h3>
                <input type="email" placeholder="Enter your email">
                <button><b>Subscribe</b></button>
                <div class="social-links">
                    <a href="#"><img src="images/FBLOGO.png" alt="Facebook"></a>
                    <a href="#"><img src="images/IGLOGO.png" alt="Instagram"></a>
                </div>
                <p>Mobile: 0912-345-6789</p>
                <p>Email: jpdc@gmail.com</p>
            </div>
        </div>
        <div class="footer-bottom">
            <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic">
            <div class="footer-bottom-links">
                <a href="#">Contact Us</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
            </div>
            <p>All Rights Reserved ©2024 Joy Pascual Dental Clinic</p>
        </div>
    </footer>

    <!-- JavaScript for 3D model -->
    <script>
    // Initialize the scene, camera, and renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xFAF9F6); // Set background to white
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer();

    // Set renderer size and append it to the container
    renderer.setSize(window.innerWidth, window.innerHeight);
    const canvas = renderer.domElement;
    document.getElementById('model-container').appendChild(canvas);     

    // Apply styles directly to the canvas
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.borderRadius = '10px';
    canvas.style.boxShadow = '0 4px 10px rgba(0, 0, 0, 0.3)';

    // Add a light source
    const light = new THREE.DirectionalLight(0xffffff, 1);
    light.position.set(1, 1, 1).normalize();
    scene.add(light);

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0x404040); 
    scene.add(ambientLight);

    // Add OrbitControls for mouse interaction
    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.screenSpacePanning = false;
    controls.maxPolarAngle = Math.PI / 2;

    let currentModel = null;
    let hoverModel = null;
    const loader = new THREE.GLTFLoader();
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    let hoverEnabled = false; // Hover is initially disabled
    let hoverAnimationActive = false; // To prevent re-triggering animation

    // Load the 3D model
    function loadModel(modelPath, callback) {
        loader.load(modelPath, function (gltf) {
            const model = gltf.scene;
            model.scale.set(2, 2, 2);
            model.position.set(0, 0, 0);
            callback(model);
        }, undefined, function (error) {
            console.error('An error happened while loading the model:', error);
        });
    }

    // Load the default model (default_new.glb)
    loadModel('images/default_new.glb', function (model) {
        currentModel = model;
        scene.add(currentModel);
    });

    // Load the hover model (used only for the teeth_yellow hover effect)
    loadModel('images/default_new.glb', function (model) {
        hoverModel = model;
        hoverModel.visible = false; // Initially hide the hover model
        scene.add(hoverModel);
    });

    // Set camera position
    camera.position.z = 5;

    // Handle mouse move to trigger hover effect (only for teeth_yellow model)
    function onMouseMove(event) {
        if (!hoverEnabled) return; // Only process hover if hover is enabled

        // Convert mouse coordinates to normalized device coordinates (-1 to +1)
        mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
        mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

        // Update the raycaster
        raycaster.setFromCamera(mouse, camera);

        // Check for intersection with the current model
        const intersects = raycaster.intersectObject(currentModel, true);

        if (intersects.length > 0) {
            // Hide the current model and show the hover model with animation
            if (!hoverAnimationActive) {
                hoverModel.visible = true;
                currentModel.visible = false;
                hoverAnimationActive = true;
                animateHoverIn(); // Trigger hover animation
            }
        } else {
            if (hoverAnimationActive) {
                animateHoverOut(); // Trigger hover-out animation
            }
        }
    }

    // Add event listener for mouse move
    window.addEventListener('mousemove', onMouseMove);

    // Function to load models via button click
    function loadModelFromButton(modelPath) {
        hoverEnabled = false; // Disable hover by default when switching models
        hoverAnimationActive = false; // Reset hover animation flag
        if (currentModel) {
            scene.remove(currentModel);
        }
        if (hoverModel) {
            hoverModel.visible = false; // Ensure hover model is hidden
        }

        loadModel(modelPath, function (model) {
            currentModel = model;
            scene.add(currentModel);
        });
    }

    // Animation loop
    function animate() {
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }
    animate();

    // Hover animation when the user hovers over the model
    function animateHoverIn() {
        const targetScale = new THREE.Vector3(3, 3, 3); // Scale up on hover
        const duration = 300; // Animation duration in milliseconds

        const start = { scale: hoverModel.scale.clone() };
        const end = { scale: targetScale };

        let startTime = performance.now();

        function animateScale(time) {
            let elapsed = time - startTime;
            let progress = Math.min(elapsed / duration, 1);

            hoverModel.scale.lerpVectors(start.scale, end.scale, progress);

            if (progress < 1) {
                requestAnimationFrame(animateScale);
            }
        }
        requestAnimationFrame(animateScale);
    }

    // Reverse hover animation when the user moves the mouse away
    function animateHoverOut() {
        const targetScale = new THREE.Vector3(2, 2, 2); // Scale back to original
        const duration = 300; // Animation duration in milliseconds

        const start = { scale: hoverModel.scale.clone() };
        const end = { scale: targetScale };

        let startTime = performance.now();

        function animateScale(time) {
            let elapsed = time - startTime;
            let progress = Math.min(elapsed / duration, 1);

            hoverModel.scale.lerpVectors(start.scale, end.scale, progress);

            if (progress < 1) {
                requestAnimationFrame(animateScale);
            } else {
                // Once the animation is done, revert back to the original model
                hoverModel.visible = false;
                currentModel.visible = true;
                hoverAnimationActive = false;
            }
        }
        requestAnimationFrame(animateScale);
    }

    // Handle window resize
    window.addEventListener('resize', function () {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // Button click handlers to load different models
    document.getElementById('service-buttons').addEventListener('click', function (event) {
        if (event.target.tagName === 'BUTTON') {
            const model = event.target.getAttribute('data-model');
            if (model) {
                loadModelFromButton(model);
            }

            // If teeth_yellow is clicked, enable hover effect
            if (model === 'images/teeth_yellow.glb') {
                hoverEnabled = true;
            }
        }
    });

    // Mapping of service names to 3D model paths
    const modelMapping = {
        'Prosthodontic Treatment - Dentures': 'images/missing_teeth.glb',
        'Orthodontic Treatment - Braces': 'images/braces.glb',
        'Esthetic Dentistry - Whitening': 'images/teeth_yellow.glb',
        'Tooth Extraction': 'images/extraction.glb' // Ensure you have this model or adjust accordingly
    };

    // Add click event listener to history list items
    document.getElementById('history-list').addEventListener('click', function(event) {
        if (event.target.classList.contains('history-item')) {
            const serviceName = event.target.getAttribute('data-service-name');
            const modelPath = modelMapping[serviceName];

            if (modelPath) {
                loadModelFromButton(modelPath); // Load the corresponding model
            } else {
                loadModelFromButton('images/default_new.glb'); // Reset if no match found
            }
        }
    });

</script>



</body>
</html>
