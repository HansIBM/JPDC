<?php
// Include the database connection file
require "adminConx.php";


// Check if the form is submitted and the necessary data is set
if (isset($_POST['updateService']) && isset($_POST['servID']) && isset($_POST['servName']) && isset($_POST['servPrice'])) {
    // Retrieve form data
    $servID = $_POST['servID'];
    $servName = $_POST['servName'];
    $servPrice = $_POST['servPrice'];

    try {
        // Prepare SQL statement to update service
        $sql = "UPDATE services SET servName = :servName, servPrice = :servPrice WHERE servID = :servID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':servName', $servName);
        $stmt->bindParam(':servPrice', $servPrice);
        $stmt->bindParam(':servID', $servID);

        // Execute the update statement
        if ($stmt->execute()) {
            // Redirect to admin services page after successful update
            header("Location: adminServices.php");
            exit();
        } else {
            // Display an error message if update fails
            header("Location:adminEditServices.php");
        }
    } catch (PDOException $e) {
        // Display error message if an exception occurs
        header("Location:adminEditServices.php");
    }
} else {
    // If form data is incomplete, redirect the user or display an error message
    header("Location:adminEditServices.php");
}

// Close the database connection
$conn = null;
?>
