<?php
session_start();
require "userConx.php";

if (!isset($_SESSION['userID'])) {
    header("Location: loginForm.php");
    exit;
}

$userID = $_SESSION['userID'];

// Get bookID and payRemBal from the URL
$bookID = isset($_GET['bookID']) ? $_GET['bookID'] : null;
$payRemBal = isset($_GET['payRemBal']) ? $_GET['payRemBal'] : null;
$userEmail = isset($_GET['userEmail']) ? $_GET['userEmail'] : null;

// Ensure bookID and payRemBal are present
if (!$bookID || !$payRemBal) {
    echo "Invalid request.";
    exit;
}

// Fetch the user's phone number
$sqlFetchPhoneNumber = "
SELECT userPhone 
FROM users 
WHERE userID = :userID";

$stmt = $conn->prepare($sqlFetchPhoneNumber);
$stmt->bindParam(':userID', $userID);
$stmt->execute();
$userResult = $stmt->fetch(PDO::FETCH_ASSOC);

if ($userResult) {
    $gcashNumber = $userResult['userPhone'];
} else {
    header("Location: userPage.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCash Payment</title>
    <link rel="stylesheet" href="userPayGcash.css">
    <script src="https://kit.fontawesome.com/1fd0899690.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <div id="paymentlogo">
            <img src="images/GCashLogo.png" alt="GCash Logo">
            <h2>GCash Payment</h2>
        </div>

        <a href="userPage.php"><i class="fa-solid fa-chevron-left"></i> Back to Payment Methods</a>
        <form action="userPayGcashSubmit.php" method="post">
            <div class="payment-fields">
                <label for="total_amount">Total Amount Fee:</label><br>
                <input type="text" id="total_amount" value="₱<?php echo number_format($payRemBal, 2); ?>" disabled><br>
                <input type="hidden" name="bookID" value="<?php echo $bookID; ?>">
                <input type="hidden" id="payment_amount" name="payment_amount" value="<?php echo $payRemBal; ?>">
                <input type="hidden" id="userEmail" name="userEmail" value="<?php echo $userEmail; ?>">
                <label for="actual_payment">Payment Amount:</label><br>
                <input type="number" id="actual_payment" name="actual_payment" required placeholder="Enter amount to pay" min="1" step="0.01"><br>
                <span>Please note that the fee is non-refundable. Minimum payment amount is ₱1.00.</span>
            </div>
            <label for="gcash_number">GCash Number:</label><br>
            <input type="text" id="gcash_number" name="gcash_number" value="<?php echo $gcashNumber; ?>" required><br>
            <button type="submit">Pay via GCash</button>
        </form>
    </div>
</body>
</html>
