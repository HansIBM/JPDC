<?php
// Start session
session_start();

// Include database connection
require "userConx.php";

// Check if user is logged in
if (!isset($_SESSION['userID'])) {
    header("Location: loginForm.php");
    exit();
}

// Get user ID from session
$userID = $_SESSION['userID'];

// Check if the form has been submitted
if (isset($_POST['update'])) {
    // Retrieve form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    //$password = $_POST['password'];

    try {
        // Get current user information from the database
        $sqlSelect = "SELECT * FROM users WHERE userID=:userID";
        $stmtSelect = $conn->prepare($sqlSelect);
        $stmtSelect->bindParam(':userID', $userID);
        $stmtSelect->execute();
        $row = $stmtSelect->fetch(PDO::FETCH_ASSOC);

        // Check if there are any changes
        if ($firstName != $row['userFName']) {
            $sqlUpdateFirstName = "UPDATE users SET userFName=:firstName WHERE userID=:userID";
            $stmtUpdateFirstName = $conn->prepare($sqlUpdateFirstName);
            $stmtUpdateFirstName->bindParam(':firstName', $firstName);
            $stmtUpdateFirstName->bindParam(':userID', $userID);
            $stmtUpdateFirstName->execute();

            // Insert audit trail action for first name change
            $sqlInsertAuditFirstName = "INSERT INTO audittrail (userID, actions) VALUES (:userID, 'Update First Name')";
            $stmtInsertAuditFirstName = $conn->prepare($sqlInsertAuditFirstName);
            $stmtInsertAuditFirstName->bindParam(':userID', $userID);
            $stmtInsertAuditFirstName->execute();
        }

        if ($lastName != $row['userLName']) {
            $sqlUpdateLastName = "UPDATE users SET userLName=:lastName WHERE userID=:userID";
            $stmtUpdateLastName = $conn->prepare($sqlUpdateLastName);
            $stmtUpdateLastName->bindParam(':lastName', $lastName);
            $stmtUpdateLastName->bindParam(':userID', $userID);
            $stmtUpdateLastName->execute();

            // Insert audit trail action for last name change
            $sqlInsertAuditLastName = "INSERT INTO audittrail (userID, actions) VALUES (:userID, 'Update Last Name')";
            $stmtInsertAuditLastName = $conn->prepare($sqlInsertAuditLastName);
            $stmtInsertAuditLastName->bindParam(':userID', $userID);
            $stmtInsertAuditLastName->execute();
        }

        if ($email != $row['userEmail']) {
            $sqlUpdateEmail = "UPDATE users SET userEmail=:email WHERE userID=:userID";
            $stmtUpdateEmail = $conn->prepare($sqlUpdateEmail);
            $stmtUpdateEmail->bindParam(':email', $email);
            $stmtUpdateEmail->bindParam(':userID', $userID);
            $stmtUpdateEmail->execute();

            // Insert audit trail action for email change
            $sqlInsertAuditEmail = "INSERT INTO audittrail (userID, actions) VALUES (:userID, 'Update Email')";
            $stmtInsertAuditEmail = $conn->prepare($sqlInsertAuditEmail);
            $stmtInsertAuditEmail->bindParam(':userID', $userID);
            $stmtInsertAuditEmail->execute();
        }

        if ($phone != $row['userPhone']) {
            $sqlUpdatePhone = "UPDATE users SET userPhone=:phone WHERE userID=:userID";
            $stmtUpdatePhone = $conn->prepare($sqlUpdatePhone);
            $stmtUpdatePhone->bindParam(':phone', $phone);
            $stmtUpdatePhone->bindParam(':userID', $userID);
            $stmtUpdatePhone->execute();

            // Insert audit trail action for phone change
            $sqlInsertAuditPhone = "INSERT INTO audittrail (userID, actions) VALUES (:userID, 'Update Phone')";
            $stmtInsertAuditPhone = $conn->prepare($sqlInsertAuditPhone);
            $stmtInsertAuditPhone->bindParam(':userID', $userID);
            $stmtInsertAuditPhone->execute();
        }

        // Redirect to user profile page
        header("Location: userPage.php");
        exit();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    // If the form was not submitted, redirect to the user profile page
    header("Location: userPage.php");
    exit();
}
?>
