<?php
session_start();
require "userConx.php";

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to loginForm.php
    header("Location: loginForm.php");
    exit();
}

// Simulated session user ID
$userId = $_SESSION['userID'];

// Query to check if the user has a booking that is confirmed but not done
$sqlFetch = "SELECT COUNT(*) FROM booking WHERE userID = :userId AND bookConfirm = 'Confirmed' AND bookStatus = 'Not Done'";
$stmt = $conn->prepare($sqlFetch);
$stmt->bindParam(':userId', $userId);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

// Get the count from the result
$bookingCount = $row['COUNT(*)'];

// Check if the user has a booking that is confirmed but not done
$isBookingConfirmedNotDone = ($bookingCount > 0);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Joy Pascual Dental Clinic</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="styles-user.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<header>
    <!-- COPY PASTE LAGI TO KASI SAME LANG NAV LINKS-->
    <div class="header-container">
        <div class="logo">
            <img src="images/ToothJPDC.png" alt="Joy Pascual Dental Clinic">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="userHomePage.php">Home</a></li>
                <li><a href="userHomePage.php#about">About</a></li>
                <li class="dropdown">
                    <a href="javascript:void(0)" class="dropbtn">Services <i class ="fas fa-chevron-down" style = "font-size: 12px; margin-left:5px"></i></a>
                    <div class="dropdown-content">
                        <a href="userModel.php">3D Teeth Model</a>
                        <a href="service1.php">Esthetic Dentistry</a>
                        <a href="service3.php">Prosthodontic Treatment</a>
                        <a href="service4.php">Orthodontic Treatment</a>
                        <a href="service5.php">Teeth Extraction</a>
                    </div>
                </li>
                <li><a href="userPage.php">Account</a></li>
            </ul>
        </nav>
        <a href="userBooking.php" class="appointment-btn">Book an Appointment</a>
    </div>
</header>


    <!-- Slideshow Section -->
    <div class="slideshow-container">
        <div class="slides fade">
            <div class="slide-content">
                <img src="images/1.png" class="slide-image" alt="Slide 1">
            </div>
        </div>
        <div class="slides fade">
            <div class="slide-content">
                <div class="slide-text1">
                    Your Path to Better Oral Health<br><em>Starts Here.</em><br><br>
                    <a href="loginForm.php" class="book-now-btn">
                        Book Now <i class="fas fa-arrow-right"></i>
                    </a>
                </div>    
                <img src="images/2.png" class="slide-image" alt="Slide 2">
            </div>
        </div>
        <div class="slides fade">
            <div class="slide-content">
                <div class="slide-text2">
                    Experience Quality Dental Care<br>
                    <p>Know our services offered to meet your dental needs</p><br>
                    <a href="#services" class="book-now-btn">
                        Check our Services <i class="fas fa-arrow-right"></i>
                    </a>
                </div>  
                <img src="images/3.png" class="slide-image" alt="Slide 3">
            </div>
        </div>
        <a class="prev" onclick="changeSlide(-1)">&#10094;</a>
        <a class="next" onclick="changeSlide(1)">&#10095;</a>
    </div>

    <section class="dental-services">
        <h2 class="abouth2">Your Trusted Partner in Dental Health</h2>
        <center>
        <p style="text-align:center" class="aboutp">At our clinic, we prioritize your dental health and well-being. Let us be your partner in achieving and maintaining a radiant smile!</p>
        </center>   
    </section>
        
        <center>
    <section class="content" id="about">
            <h2 class="abouth2">Meet the Dentists</h2>
        
            <div class="about-container">
                <img src="images/Dra1.png" alt="Dentist Image" class="dentist-image">
                <div class="about-text">
                    <h3>Dr. Josephine P. Pascual (Head Dentist)</h3>
                    <p>-Centro Escolar University Manila Alumna Batch 1986<br>
                    -Specialization: General Dentistry, Orthodontics, Prosthodontics

                </p>
                </div>
            </div>

            <div class="about-container">
                <img src="images/Dra2.png" alt="Dentist Image" class="dentist-image">
                <div class="about-text">
                    <h3>Dr. Franchesca P. Eusebio (Associate Dentist)</h3>
                    <p>-Centro Escolar University Manila Alumna Batch 2020<br>
                    -Specialization: General Dentistry, Orthodontics, Esthetics, Surgery

                    </p>
                </div>
            </div>
        </section>
    </center>


    <section class="services" id="services">
        <h2 class="abouth2">Services</h2>
        <center><p class="aboutp">Here are the services we offer here at Joy Pascual Dental Clinic:</p></center>
        <div class="service-tiles">
            <div class="service-tile">
                <a href="service1.php"><img src="images/whitening.jpg" alt="Esthetic Dentistry - Whitening" class="service-image"></a>
                <h3 class="service-title">Esthetic Dentistry - Whitening</h3>
            </div>
            <div class="service-tile">
                <a href="service2.php"><img src="images/denture.jpg" alt="Prosthodontic Treatment - Dentures" class="service-image"></a>
                <h3 class="service-title">Prosthodontic Treatment - Dentures</h3>
            </div>
            <div class="service-tile">
                <a href="service3.php"><img src="images/braces.jpg" alt="Orthodontic Treatment - Braces" class="service-image"></a>
                <h3 class="service-title">Orthodontic Treatment - Braces</h3>
            </div>
            <div class="service-tile">
                <a href="service4.php"><img src="images/extraction.jpg" alt="Tooth Extraction" class="service-image"></a>
                <h3 class="service-title">Tooth Extraction</h3>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <div class="footer-container">
            <div class="footer-column">
                <h3>Useful Links</h3>
                <a href="#">Home</a>
                <a href="#">About</a>
                <a href="#">Services</a>
            </div>
            <div class="footer-column">
                <h3>Contact Us</h3>
                <a href="#">Contact Form</a>
                <a href="#">FAQ</a>
            </div>
            <div class="footer-column newsletter">
                <h3>Newsletter</h3>
                <input type="email" placeholder="Enter your email">
                <button><b>Subscribe</b></button>
                <div class="social-links">
                    <a href="#"><img src="images/FBLOGO.png" alt="Facebook"></a>
                    <a href="#"><img src="images/IGLOGO.png" alt="Instagram"></a>
                </div>
                <p>Mobile: 0912-345-6789</p>
                <p>Email: jpdc@gmail.com</p>
            </div>
        </div>
        <div class="footer-bottom">
            <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic">
            <div class="footer-bottom-links">
                <a href="#">Contact Us</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
            </div>
            <p>All Rights Reserved ©2024 Joy Pascual Dental Clinic</p>
        </div>
    </footer>

    <?php if ($isBookingConfirmedNotDone): ?>
        <div id="bookingModal" class="modal" style="display:block;">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h2>Booking Notification</h2>
                <p>Your booking has been confirmed. <br>Check your appointment <a href="userPage.php">here</a>.</p>
            </div>
        </div>
    <?php endif; ?>

    <!-- Scripts for the slideshow -->
    <script>
         // JavaScript to show the modal if the booking is confirmed and not done
         var isBookingConfirmedNotDone = <?php echo json_encode($isBookingConfirmedNotDone); ?>;

        // If booking is confirmed and not done, show the modal
        if (isBookingConfirmedNotDone) {
            var modal = document.getElementById("bookingModal");
            var span = document.getElementsByClassName("close")[0];

            modal.style.display = "block";

            // Close the modal when the user clicks on the close button (x)
            span.onclick = function() {
                modal.style.display = "none";
            }

            // Close the modal when the user clicks anywhere outside of the modal
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        }


        let slideIndex = 0;
        showSlides();

        function showSlides() {
            let slides = document.getElementsByClassName("slides");
            for (let i = 0; i < slides.length; i++) {
                slides[i].style.display = "none"; // Hide all slides
            }
            slideIndex++;
            if (slideIndex > slides.length) { slideIndex = 1 } // Reset to first slide
            slides[slideIndex - 1].style.display = "block"; // Show current slide
            setTimeout(showSlides, 3000); // Change slide every 3 seconds
        }

        function changeSlide(n) {
            slideIndex += n;
            if (slideIndex > document.getElementsByClassName("slides").length) { slideIndex = 1 }
            if (slideIndex < 1) { slideIndex = document.getElementsByClassName("slides").length }
            showSlidesManually();
        }

        function showSlidesManually() {
            let slides = document.getElementsByClassName("slides");
            for (let i = 0; i < slides.length; i++) {
                slides[i].style.display = "none"; // Hide all slides
            }
            slides[slideIndex - 1].style.display = "block"; // Show the current slide
        }
    </script>
</body>
</html>



