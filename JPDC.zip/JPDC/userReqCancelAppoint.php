<?php
session_start();
require "userConx.php";

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to loginForm.php
    header("Location: loginForm.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['bookID'])) {
    $bookID = $_POST['bookID'];
    
    try {
        // Fetch the bookTime based on the bookID
        $sqlFetchBookTime = "SELECT bookTime FROM booking WHERE bookID = :bookID";
        $stmtFetchBookTime = $conn->prepare($sqlFetchBookTime);
        $stmtFetchBookTime->bindParam(':bookID', $bookID);
        $stmtFetchBookTime->execute();
        $bookTimeResult = $stmtFetchBookTime->fetch(PDO::FETCH_ASSOC);
        
        // Extract the bookTime from the result
        $bookTime = $bookTimeResult['bookTime'];

        // Update the booking status to "Requested" and "Waiting for Cancellation"
        $sqlUpdateCancelStatus = "UPDATE booking SET bookCancel = 'Requested', bookStatus = 'Waiting for Cancellation' WHERE bookID = :bookID";
        $stmt = $conn->prepare($sqlUpdateCancelStatus);
        $stmt->bindParam(':bookID', $bookID);
        $stmt->execute();

        // Get the current date and time
        $auditDateTime = date("Y-m-d H:i:s");

        // Prepare the audit trail message
        $auditMessage = "Requested cancellation of appointment for booking ID: $bookID Date: " . date('l, F jS, Y') . " Time: $bookTime";

        // Insert the audit trail record
        $sqlAudit = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, :actions, :auditDateTime)";
        $stmtAudit = $conn->prepare($sqlAudit);
        // Assuming the userID is stored in the session
        $stmtAudit->bindParam(':userID', $_SESSION['userID']);
        $stmtAudit->bindParam(':actions', $auditMessage);
        $stmtAudit->bindParam(':auditDateTime', $auditDateTime);
        $stmtAudit->execute();

        // Redirect back to the user appointments page
        header("Location: userAppointments.php");
        exit;
    } catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    $conn = null;
} else {
    echo "Invalid request.";
}
?>
