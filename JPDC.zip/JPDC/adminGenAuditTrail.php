<?php
// Include TCPDF library
session_start();
require_once('tcpdf/tcpdf.php');
require('adminConx.php');

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

// Query to retrieve data for the audit trail
$sql = "SELECT audittrail.*, users.userFName, users.userLName 
        FROM audittrail
        INNER JOIN users ON audittrail.userID = users.userID
        ORDER BY audittrail.auditDateTime DESC";

$stmt = $conn->query($sql);

// Group audit trail entries by month and day
function groupAuditTrailByMonthAndDay($entries) {
    $groupedEntries = [];
    foreach ($entries as $entry) {
        $timestamp = strtotime($entry['auditDateTime']);
        $monthYear = date('F Y', $timestamp);
        $day = date('F j, Y', $timestamp);
        if (!isset($groupedEntries[$monthYear])) {
            $groupedEntries[$monthYear] = [];
        }
        if (!isset($groupedEntries[$monthYear][$day])) {
            $groupedEntries[$monthYear][$day] = [];
        }
        $groupedEntries[$monthYear][$day][] = $entry;
    }
    return $groupedEntries;
}

$groupedAuditTrail = groupAuditTrailByMonthAndDay($stmt->fetchAll(PDO::FETCH_ASSOC));

// Initialize TCPDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Admin');
$pdf->SetTitle('Audit Trail Report');
$pdf->SetSubject('Audit Trail Report');
$pdf->SetKeywords('TCPDF, PDF, report');

// Remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', '', 10);

// Loop through grouped audit trail entries and output each month and day
foreach ($groupedAuditTrail as $month => $days) {
    $pdf->SetFont('helvetica', 'B', 16);
    $pdf->Cell(0, 10, $month, 0, 1, 'C');
    foreach ($days as $day => $entries) {
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 10, $day, 0, 1, 'C');
        // Table header
        $pdf->SetFont('helvetica', 'B', 10);
        $pdf->SetFillColor(200, 200, 200); // Set header background color
        $pdf->Cell(25, 10, 'Audit ID', 1, 0, 'C', true);
        $pdf->Cell(40, 10, 'Name', 1, 0, 'C', true);
        $pdf->Cell(70, 10, 'Action', 1, 0, 'C', true);
        $pdf->Cell(50, 10, 'Timestamp', 1, 1, 'C', true);
        // Table data
        $pdf->SetFont('helvetica', '', 10);
        foreach ($entries as $entry) {
            $pdf->Cell(25, 10, $entry["auditID"], 1, 0, 'C');
            $pdf->Cell(40, 10, $entry["userFName"] . " " . $entry["userLName"], 1, 0, 'C');
            $pdf->SetFont('helvetica', '', 10);
            // Output action with line breaks if necessary
            $pdf->writeHTMLCell(70, 10, '', '', nl2br($entry["actions"]), 1, 0, false, true, 'L', true);
            $pdf->Cell(50, 10, $entry["auditDateTime"], 1, 1, 'C');
        }
    }
}

// Close and output PDF document
$pdf->Output('audit_trail_report.pdf', 'D');
