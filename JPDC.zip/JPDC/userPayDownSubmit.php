<?php
session_start();
require "userConx.php";
require 'PHPMailer/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['userID'])) {
    header("Location: loginForm.php");
    exit;
}

$userID = $_SESSION['userID'];

// Get form data
$bookID = $_POST['bookID'] ?? null;
$paymentAmount = $_POST['actual_payment'] ?? null;
$gcashNumber = $_POST['gcash_number'] ?? null;
$userEmail = $_POST["userEmail"] ?? null;
$selectedDate = $_POST["selectedDate"] ?? null;
$selectedSlot = $_POST["selectedSlot"] ?? null;

// Validate input
if (empty($bookID) || empty($paymentAmount) || empty($gcashNumber)) {
    echo "Invalid input.";
    exit;
}

// Fetch current payment balance and service name
$sqlFetchService = "
SELECT s.servName, p.payRemBal 
FROM payment p
JOIN booking b ON p.bookID = b.bookID
JOIN services s ON b.servID = s.servID
WHERE p.bookID = :bookID 
ORDER BY p.payDateTime DESC 
LIMIT 1";

$stmt = $conn->prepare($sqlFetchService);
$stmt->bindParam(':bookID', $bookID);
$stmt->execute();
$serviceResult = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$serviceResult) {
    logAuditTrail($conn, $userID, "Failed to fetch payment record for booking ID: $bookID");
    echo "No payment record found for this booking.";
    exit;
}

$currentRemBal = $serviceResult['payRemBal'];
$serviceName = $serviceResult['servName'];
$newRemBal = max(0, $currentRemBal - $paymentAmount); // Calculate new balance, ensuring it doesn't go negative


// Get service details associated with the booking
$getServiceDetails = "
                SELECT 
                    b.servID, 
                    s.servName, 
                    b.bookSched 
                FROM 
                    booking b 
                INNER JOIN 
                    services s ON b.servID = s.servID 
                WHERE 
                    b.bookID = :bookID";

$stmtServiceDetails = $conn->prepare($getServiceDetails);
$stmtServiceDetails->bindParam(':bookID', $bookID);
$stmtServiceDetails->execute();
$serviceDetails = $stmtServiceDetails->fetch(PDO::FETCH_ASSOC);

$servID = $serviceDetails['servID'];
$servName = $serviceDetails['servName'];
$serviceDate = $serviceDetails['bookSched'];
$notes = "Completed successfully"; // Add any notes you wish
$createdAt = date('Y-m-d H:i:s');


// Generate a 6-digit reference number
$payDownRef = sprintf('%06d', mt_rand(0, 999999));

// Update the payment record
$sqlUpdatePayment = "
    UPDATE payment 
    SET payRemBal = :newRemBal, 
        payDownRef = :payDownRef,
        payDateTime = NOW(),
        payMethod = CASE WHEN :newRemBal = 0 THEN 'GCASH' ELSE payMethod END,
        payStatus = CASE WHEN :newRemBal = 0 THEN 'Paid' ELSE payStatus END
    WHERE bookID = :bookID AND payRemBal = :currentRemBal";

$stmt = $conn->prepare($sqlUpdatePayment);
$stmt->bindParam(':bookID', $bookID);
$stmt->bindParam(':newRemBal', $newRemBal);
$stmt->bindParam(':payDownRef', $payDownRef);
$stmt->bindParam(':currentRemBal', $currentRemBal);

if ($stmt->execute()) {
    // Log payment update action with details
    if ($newRemBal == 0) {
        logAuditTrail($conn, $userID, "Made a full payment for booking ID: $bookID. Payment Amount: ₱$paymentAmount, Reference Number: $payDownRef, New Remaining Balance: ₱0.");
    } else {
        logAuditTrail($conn, $userID, "Made a down payment for booking ID: $bookID. Payment Amount: ₱$paymentAmount, Reference Number: $payDownRef, New Remaining Balance: ₱$newRemBal.");
    }

    // Only update booking if the remaining balance is 0
    if ($newRemBal == 0) {
        $updateBooking = "UPDATE booking SET bookStatus = 'Done' WHERE bookID = :bookID";
        $stmtBooking = $conn->prepare($updateBooking);
        $stmtBooking->bindParam(':bookID', $bookID);
        $stmtBooking->execute();

        // Insert into services_done
        $insertServiceDone = "INSERT INTO services_done (userID, serviceID, serviceName, serviceDateDone, serviceNotes, serviceDateTime) VALUES (:userID, :serviceID, :serviceName, :serviceDateDone, :serviceNotes, NOW())";
        $stmtServiceDone = $conn->prepare($insertServiceDone);
        $stmtServiceDone->bindParam(':userID', $userID);
        $stmtServiceDone->bindParam(':serviceID', $servID);
        $stmtServiceDone->bindParam(':serviceName', $servName);
        $stmtServiceDone->bindParam(':serviceDateDone', $serviceDate);
        $stmtServiceDone->bindParam(':serviceNotes', $notes);
        $stmtServiceDone->execute();
    }

    // Generate and send the receipt
    $receiptHtml = generateReceipt($bookID, $paymentAmount, $payDownRef, $newRemBal, $userEmail, $selectedDate, $selectedSlot, $serviceName);
    echo $receiptHtml;

    if (!sendEmailReceipt($userEmail, $bookID, $paymentAmount, $payDownRef, $newRemBal, $selectedDate, $selectedSlot, $serviceName)) {
        echo "Error sending email receipt.";
    }
} else {
    logAuditTrail($conn, $userID, "Error updating payment for booking ID: $bookID.");
    echo "Error updating payment.";
}

// Function to log audit trail
function logAuditTrail($conn, $userID, $action) {
    $sqlLogAudit = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, :action, NOW())";
    $stmtAudit = $conn->prepare($sqlLogAudit);
    $stmtAudit->bindParam(':userID', $userID);
    $stmtAudit->bindParam(':action', $action);
    $stmtAudit->execute();
}

// Function to generate receipt
function generateReceipt($bookID, $paymentAmount, $payDownRef, $newRemBal, $userEmail, $selectedDate, $selectedSlot, $serviceName) {
    ob_start(); // Start output buffering
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment Receipt</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f5f5f5;
            }
            .receipt-container {
                width: 80%;
                max-width: 600px;
                margin: 20px auto;
                padding: 20px;
                background-color: #fff;
                border: 1px solid #ccc;
                border-radius: 5px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            h1 {
                text-align: center;
                color: #333;
            }
            p {
                font-size: 16px;
                margin: 5px 0;
            }
            .return-button {
                display: block;
                margin: 20px auto;
                padding: 10px 20px;
                font-size: 16px;
                color: #fff;
                background-color: #007BFF;
                border: none;
                border-radius: 5px;
                text-align: center;
                text-decoration: none;
                cursor: pointer;
            }
            .return-button:hover {
                background-color: #0056b3;
            }
        </style>
    </head>
    <body>
        <div class="receipt-container">
            <h1>Payment Receipt</h1>
            <p><strong>Reference Number:</strong> <?php echo $payDownRef; ?></p>
            <p><strong>Book ID:</strong> <?php echo $bookID; ?></p>
            <p><strong>Service:</strong> <?php echo $serviceName; ?></p>
            <p><strong>Payment Amount:</strong> ₱<?php echo number_format($paymentAmount, 2); ?></p>
            <p><strong>Payment Method:</strong> GCash</p>
            <p><strong>Date and Time:</strong> <?php echo date("Y-m-d H:i:s"); ?></p>
            <p>Thank you for your payment!</p>
            <a href="userPage.php" class="return-button">Return to Appointments</a>
        </div>
    </body>
    </html>
    <?php
    return ob_get_clean(); // Return the buffered content
}

// Function to send email receipt
function sendEmailReceipt($userEmail, $bookID, $paymentAmount, $payDownRef, $newRemBal, $selectedDate, $selectedSlot, $serviceName) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'hansdc0203@gmail.com'; // Your SMTP username
        $mail->Password   = 'izojelwy rgnr wutm'; // Your SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('noreply@JPDC.com', 'Joy Pascual Dental Clinic');
        $mail->addAddress($userEmail); // User's email

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Appointment Confirmation';
        $mail->Body    = 
                         "You have successfully booked an appointment with the following details:<br>" .
                         "Service: $serviceName<br>" . 
                         "Service Price: ₱" . number_format($_SESSION['servicePrice'], 2) . "<br>" .
                         "Scheduled Date: $selectedDate<br>" .
                         "Time Slot: $selectedSlot<br>" .
                         "Status: Confirmed<br><br>" .
                         "<strong>Payment Receipt</strong><br>" .
                         "Reference Number: $payDownRef<br>" .
                         "Book ID: $bookID<br>" .
                         "Payment Amount: ₱" . number_format($paymentAmount, 2) . "<br>" .
                         "New Remaining Balance: ₱" . number_format($newRemBal, 2) . "<br>" .
                         "Payment Method: GCash<br><br>" .
                         "Thank you for choosing our clinic.<br>" .
                         "Best regards,<br>" .
                         "Joy Pascual Dental Clinic";

        // Send the email
        return $mail->send();
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}
?>
