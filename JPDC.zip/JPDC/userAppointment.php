<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Joy Pascual Dental Clinic</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="accountstyles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header Section -->
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="images/ToothJPDC.png" alt="Joy Pascual Dental Clinic">
            </div>
            <nav>
                <ul class="nav-links">
                    <li><a href="userHomePage.php">Home</a></li>
                    <li><a href="userHomePage.php#about">About</a></li>
                    <li><a href="userHomePage.php#services">Services</a></li>
                    <li><a href="account.html"><b>Account<b></a></li>
                </ul>
            </nav>
            <a href="userBooking.php" class="appointment-btn">Book an Appointment</a>
        </div>
    </header>

    <!-- Sidebar and Account Section -->
    <div class="container">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="#" class="menu-item" id="account-menu">My Account</a></li>
                <li><a href="#" id="my-appointments" class="active">My Appointments</a></li>
                <li><a href="#" id="change-password" class="menu-item">Change Password</a></li>
            </ul>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="submit" name="logout" value="Logout" class="btn btn-danger" id="logout-btn">
            </form>
        </aside>

        <main class="account-details" id="account-section">
            <?php
                session_start();
                require "userConx.php";

                // Check if the user is logged in
                if (!isset($_SESSION['userID'])) {
                    header("Location: index.php");
                    exit;
                }

                $userID = $_SESSION['userID'];

                if (isset($_POST['logout'])) {
                    try {
                        $sqlInsertAudit = "INSERT INTO audittrail (userID, actions) values (:userID, 'Logged Out')";
                        $stmt = $conn->prepare($sqlInsertAudit);
                        $stmt->bindParam(':userID', $userID);
                        $stmt->execute();
                    } catch (PDOException $e) {
                        echo "Error: " . $e->getMessage();
                    }

                    session_destroy();
                    header("Location: index.php");
                    exit;
                }

                try {
                    $sqlFetch = "SELECT * FROM users WHERE userID = :userID";
                    $stmt = $conn->prepare($sqlFetch);
                    $stmt->bindParam(':userID', $userID);
                    $stmt->execute();
                    $row = $stmt->fetch(PDO::FETCH_ASSOC);
                } catch (PDOException $e) {
                    echo "Error: " . $e->getMessage();
                }
            ?>
            <?php
            if (isset($_SESSION["errorType"])) {
                $errorMessage = "";
                switch ($_SESSION["errorType"]) {
                    case "incorrectPassword":
                        $errorMessage = "The current password you entered is incorrect.";
                        break;
                    case "passwordMismatch":
                        $errorMessage = "The new password and confirmation do not match.";
                        break;
                    case "success":
                        $errorMessage = "Your password has been changed successfully.";
                        break;
                }
                unset($_SESSION["errorType"]); // Clear the session variable after use
            }
            ?>


            <?php if ($stmt->rowCount() > 0) { ?>
                <h2>My Account Details</h2>
                <br>
                <form method="post" action="userUpdateProfile.php">
                    <label for="firstName">First Name:</label>
                    <input type="text" id="firstName" name="firstName" value="<?php echo $row["userFName"]; ?>" required pattern="[a-zA-Z\s.]+" title="Only alphabetic characters, spaces, and dots are allowed">

                    <label for="lastName">Last Name:</label>
                    <input type="text" id="lastName" name="lastName" value="<?php echo $row["userLName"]; ?>" required pattern="[a-zA-Z\s.]+" title="Only alphabetic characters, spaces, and dots are allowed">

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo $row["userEmail"]; ?>" required>

                    <label for="phone">Phone:</label>
                    <input type="tel" id="phone" name="phone" value="<?php echo $row["userPhone"]; ?>" required pattern="09\d{9}" title="Phone number must start with '09' followed by 9 digits">

                    <button type="submit" class="save-changes-btn">Save Changes</button>
                </form>
            <?php } ?>
        </main>

        <!-- My Appointments Section -->
        <div id="appointments-section" class="appointments-section" style="display: none;">
            <h2>My Appointments</h2>
            <div class="appt">
                <h3>Pending Appointments</h3>
                <p>No pending appointments found.</p>
                <h3>Appointment History</h3>
                <ul class="appointments-history">
                    <li>Appointment on [Date] - Completed</li>
                    <li>Appointment on [Date] - Canceled</li>
                    <li>Appointment on [Date] - Completed</li>
                </ul>
            </div>
        </div>

        <!-- Change Password Section -->
         <section class="change-pass">
            <div id="change-password-section" class="change-password-section" style="display: none;">
                <h2>Change Password</h2>
                <form method="post" action="userChangePassSubmit.php">
                <?php if (isset($_SESSION["error"]) && !empty($_SESSION["error"])) { ?>
                    <div class="error-message" id="error-message"><?php echo $_SESSION["error"]; ?></div>
                    <?php
                    // Clear the error message from the session after displaying it
                    unset($_SESSION["error"]);
                    ?>
                <?php } ?>
                    <label for="current-password">Current Password:</label>
                    <input type="password" id="current-password" name="current-password" required>

                    <label for="new-password">New Password:</label>
                    <input type="password" id="new-password" name="new-password" required>

                    <label for="confirm-new-password">Confirm New Password:</label>
                    <input type="password" id="confirm-new-password" name="confirm-new-password" required>

                    <button type="submit" class="change-password-btn">Change Password</button>
                </form>
            </div>
        </section>
    </div>

    <footer>
        <div class="footer-container">
            <div class="footer-column">
                <h3>Useful Links</h3>
                <a href="#">Home</a>
                <a href="#">About</a>
                <a href="#">Services</a>
            </div>
            <div class="footer-column">
                <h3>Contact Us</h3>
                <a href="#">Contact Form</a>
                <a href="#">FAQ</a>
            </div>
            <div class="footer-column newsletter">
                <h3>Newsletter</h3>
                <input type="email" placeholder="Enter your email">
                <button><b>Subscribe</b></button>
                <div class="social-links">
                    <a href="#"><img src="images/FBLOGO.png" alt="Facebook"></a>
                    <a href="#"><img src="images/IGLOGO.png" alt="Instagram"></a>
                </div>
                <p>Mobile: 0912-345-6789</p>
                <p>Email: jpdc@gmail.com</p>
            </div>
        </div>
        <div class="footer-bottom">
            <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic">
            <div class="footer-bottom-links">
                <a href="#">Contact Us</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
            </div>
            <p>All Rights Reserved ©2024 Joy Pascual Dental Clinic</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
        const appointmentsMenuItem = document.getElementById('my-appointments');
        const accountMenuItem = document.getElementById('account-menu');
        const changePasswordMenuItem = document.getElementById('change-password');
        const appointmentsSection = document.getElementById('appointments-section');
        const accountDetails = document.getElementById('account-section');
        const changePasswordSection = document.getElementById('change-password-section');
        const errorModal = document.getElementById('errorModal');
        const modalMessage = document.getElementById('modalMessage');
        const closeButton = document.querySelector('.close-button');

        accountDetails.style.display = 'none';
        appointmentsSection.style.display = 'block';
        changePasswordSection.style.display = 'none';

        appointmentsMenuItem.addEventListener('click', function(event) {
            event.preventDefault();
            appointmentsSection.style.display = 'block';
            accountDetails.style.display = 'none';
            changePasswordSection.style.display = 'none';

            appointmentsMenuItem.classList.add('active');
            accountMenuItem.classList.remove('active');
            changePasswordMenuItem.classList.remove('active');
        });

        accountMenuItem.addEventListener('click', function(event) {
            event.preventDefault();
            accountDetails.style.display = 'block';
            appointmentsSection.style.display = 'none';
            changePasswordSection.style.display = 'none';

            accountMenuItem.classList.add('active');
            appointmentsMenuItem.classList.remove('active');
            changePasswordMenuItem.classList.remove('active');
        });

        changePasswordMenuItem.addEventListener('click', function(event) {
            event.preventDefault();
            changePasswordSection.style.display = 'block';
            accountDetails.style.display = 'none';
            appointmentsSection.style.display = 'none';

            changePasswordMenuItem.classList.add('active');
            accountMenuItem.classList.remove('active');
            appointmentsMenuItem.classList.remove('active');
        });

        // Show modal if there is an error message
        <?php if (isset($errorMessage) && !empty($errorMessage)) { ?>
            modalMessage.textContent = "<?php echo addslashes($errorMessage); ?>";
            errorModal.style.display = 'block';
        <?php } ?>

        // Close the modal when the close button is clicked
        closeButton.addEventListener('click', function() {
            errorModal.style.display = 'none';
        });

        // Close the modal when clicking outside of the modal content
        window.addEventListener('click', function(event) {
            if (event.target == errorModal) {
                errorModal.style.display = 'none';
            }
        });
    });

    </script>
    <!-- Modal for displaying error messages -->
    <div id="errorModal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close-button">&times;</span>
            <p id="modalMessage"></p>
        </div>
    </div>
    <style>
    /* Basic styles for the modal */
    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1000; /* Sit on top */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgba(0, 0, 0, 0.5); /* Black w/ opacity */
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto; /* 15% from the top and centered */
        padding: 20px;
        border: 1px solid #888;
        width: 80%; /* Could be more or less, depending on screen size */
    }

    .close-button {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close-button:hover,
    .close-button:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
    </style>
</body>
</html>
