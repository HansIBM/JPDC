<?php
// Include the database connection file
require "adminConx.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

// Check if the servID is set in the query parameters
if (isset($_POST['servID'])) {
    // Retrieve the servID from the query parameters
    $servID = $_POST['servID'];

    try {
        // Prepare the SQL query to delete the service
        $sql = "DELETE FROM services WHERE servID = :servID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':servID', $servID);
        $stmt->execute();

        // Redirect back to the services list page after deletion
        header("Location: adminServices.php");
        exit();
    } catch (PDOException $e) {
        // Handle any errors
        echo "Error: " . $e->getMessage();
    }
} else {
    // If servID is not set, display an error message
    echo "Service ID not provided.";
}

// Close the database connection
$conn = null;
?>
