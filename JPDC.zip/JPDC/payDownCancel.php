<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    header("Location: index.php");
    exit();
}

// Include the database connection file
require "userConx.php";

// Check if the booking ID is set in the POST request
$bookID = isset($_POST['bookID']) ? $_POST['bookID'] : null;
$userID = $_SESSION['userID'];

if ($bookID) {
    try {
        // Begin a transaction
        $conn->beginTransaction();

        // Delete the payment record associated with the booking
        $deletePaymentQuery = "DELETE FROM payment WHERE bookID = :bookID";
        $deletePaymentStmt = $conn->prepare($deletePaymentQuery);
        $deletePaymentStmt->bindParam(':bookID', $bookID, PDO::PARAM_INT);
        $deletePaymentStmt->execute();

        // Delete the booking record
        $deleteBookingQuery = "DELETE FROM booking WHERE bookID = :bookID AND userID = :userID";
        $deleteBookingStmt = $conn->prepare($deleteBookingQuery);
        $deleteBookingStmt->bindParam(':bookID', $bookID, PDO::PARAM_INT);
        $deleteBookingStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $deleteBookingStmt->execute();

        // Insert into audit trail
        $auditAction = "Canceled appointment with ID: $bookID";
        $insertAuditQuery = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, :actions, NOW())";
        $insertAuditStmt = $conn->prepare($insertAuditQuery);
        $insertAuditStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $insertAuditStmt->bindParam(':actions', $auditAction, PDO::PARAM_STR);
        $insertAuditStmt->execute();

        // Commit the transaction
        $conn->commit();

        // Redirect to userBooking.php
        header("Location: userBooking.php");
        exit();
        
    } catch (PDOException $e) {
        // Rollback the transaction if an error occurs
        $conn->rollBack();
        // Handle any errors that occur during deletion
        echo "Error deleting booking: " . $e->getMessage();
    }
} else {
    // If no booking ID is provided, redirect to userBooking.php
    header("Location: userBooking.php");
    exit();
}

// Close the PDO connection
$conn = null;
?>
