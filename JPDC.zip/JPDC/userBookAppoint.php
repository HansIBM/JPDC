<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to index.php
    header("Location: index.php");
    exit(); // Ensure no further code is executed
}

// Include the database connection file
require "userConx.php";
require 'PHPMailer/vendor/autoload.php'; // Include PHPMailer autoload file

// Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required fields are provided
    if (isset($_POST['service'], $_POST['appointment_date'], $_POST['time_slot'])) {
        // Retrieve the user ID from the session
        $userID = $_SESSION['userID'];
        
        // Retrieve other form data
        $serviceID = $_POST['service'];
        $selectedDate = $_POST['appointment_date'];
        $selectedSlot = $_POST['time_slot'];

        try {
            // Begin a transaction
            $conn->beginTransaction();

            // Fetch user email from the users table
            $userEmailQuery = "SELECT userEmail FROM users WHERE userID = :userID";
            $userEmailStmt = $conn->prepare($userEmailQuery);
            $userEmailStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
            $userEmailStmt->execute();
            $userEmailResult = $userEmailStmt->fetch(PDO::FETCH_ASSOC);

            // Check if user email is retrieved
            if ($userEmailResult) {
                $userEmail = $userEmailResult['userEmail'];
            } else {
                throw new Exception("User email not found.");
            }

            // Fetch service price
            $servicePriceQuery = "SELECT servPrice FROM services WHERE servID = :servID";
            $servicePriceStmt = $conn->prepare($servicePriceQuery);
            $servicePriceStmt->bindParam(':servID', $serviceID, PDO::PARAM_INT);
            $servicePriceStmt->execute();
            $servicePriceResult = $servicePriceStmt->fetch(PDO::FETCH_ASSOC);

            // Check if service price is retrieved
            if ($servicePriceResult) {
                $servicePrice = $servicePriceResult['servPrice'];
                $_SESSION['servicePrice'] = $servicePrice; // Store the price in session
            } else {
                throw new Exception("Service price not found.");
            }

            // Insert the booking into the bookings table with status "Confirmed"
            // Insert the booking into the bookings table with status "Confirmed"
            $insertBookingQuery = "INSERT INTO booking (userID, servID, bookSched, bookTime, bookSlotAvail, bookDateTime, bookConfirm, bookStatus) VALUES (:userID, :servID, :bookSched, :bookTime, 'Yes', NOW(), 'Confirmed', 'Not Done')";
            $insertBookingStmt = $conn->prepare($insertBookingQuery);
            $insertBookingStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
            $insertBookingStmt->bindParam(':servID', $serviceID, PDO::PARAM_INT);
            $insertBookingStmt->bindParam(':bookSched', $selectedDate, PDO::PARAM_STR);
            $insertBookingStmt->bindParam(':bookTime', $selectedSlot, PDO::PARAM_STR);
            $insertBookingStmt->execute();

            // Get the last inserted bookID
            $bookID = $conn->lastInsertId();

          

            $sqlInsertPayment = "INSERT INTO payment (bookID, payRemBal, payDownRef, payFullRef, payMethod, payStatus, payDateTime) VALUES (:bookID, :payRemBal, NULL, NULL, NULL, 'Not Fully Paid', NOW())";
            $stmt = $conn->prepare($sqlInsertPayment);
            $stmt->bindParam(':bookID', $bookID);
            $stmt->bindParam(':payRemBal', $servicePrice);
        
            $stmt->execute();


            // Insert into audit trail
            $auditAction = "Booked an appointment";
            $insertAuditQuery = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, :actions, NOW())";
            $insertAuditStmt = $conn->prepare($insertAuditQuery);
            $insertAuditStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
            $insertAuditStmt->bindParam(':actions', $auditAction, PDO::PARAM_STR);
            $insertAuditStmt->execute();

            // Commit the transaction
            $conn->commit();
            header("Location: userPayDown.php?bookID=$bookID&payRemBal=$servicePrice&selectedDate=$selectedDate&selectedSlot=$selectedSlot&userEmail=$userEmail");
        } catch (PDOException $e) {
            // Rollback the transaction if an error occurs
            $conn->rollBack();
            // Handle any errors that occur during insertion
            echo "Error inserting booking: " . $e->getMessage();
        }
    } else {
        echo "All fields are required.";
    }
}

function generateReferenceNumber() {
    return str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
}

// Example usage

$conn = null; // Close the PDO connection
?>
