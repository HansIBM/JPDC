<?php
// Include the database connection file
require "adminConx.php";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input data
    $servName = htmlspecialchars(trim($_POST["servName"]));
    $servPrice = htmlspecialchars(trim($_POST["servPrice"]));

    // Prepare and execute SQL statement to insert the new service
    try {
        $sql = "INSERT INTO services (servName, servPrice) VALUES (:servName, :servPrice)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':servName', $servName);
        $stmt->bindParam(':servPrice', $servPrice);
        $stmt->execute();

        // Redirect to the services list page after adding the service
        header("Location: adminServices.php");
        exit();
    } catch (PDOException $e) {
        // Handle errors if the insertion fails
        header("Location: adminAddServices.php");
    }
}

// Close the database connection
$conn = null;
?>
