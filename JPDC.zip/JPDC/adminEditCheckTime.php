<?php
// Include the database connection file
require "adminConx.php";

// Check if the form data is submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $bookID = $_POST["bookID"];
    $checkInTime = $_POST["checkInTime"];
    $checkOutTime = $_POST["checkOutTime"];

    try {
        // Update the check-in and check-out times in the database
        $sqlUpdate = "UPDATE booking SET bookCheckIn = :checkInTime, bookCheckOut = :checkOutTime WHERE bookID = :bookID";
        $stmt = $conn->prepare($sqlUpdate);
        $stmt->bindParam(':checkInTime', $checkInTime);
        $stmt->bindParam(':checkOutTime', $checkOutTime);
        $stmt->bindParam(':bookID', $bookID);
        $stmt->execute();

        header("Location: adminAppointList.php");
        exit();
    } catch (PDOException $e) {
        // Error occurred
        header("Location: adminAppointList.php");
        exit();
    }
} else {
    // If the request method is not POST, return an error
    header("Location: adminAppointList.php");
        exit();
}

// Close the database connection
$conn = null;
?>
