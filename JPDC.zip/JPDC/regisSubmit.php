<?php
session_start(); 
require 'adminConx.php';
require 'PHPMailer/vendor/autoload.php'; // Include PHPMailer autoload file

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Retrieve form data
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$pass = $_POST['password'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$city = $_POST['city'];
$prov = $_POST['prov'];
$medcon = $_POST['medcon'];

$hashed_pass = password_hash($pass, PASSWORD_DEFAULT);

try {
    // Check if email already exists
    $emailCheck = "SELECT COUNT(*) FROM users WHERE userEmail = :email";
    $stmt = $conn->prepare($emailCheck);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    if ($stmt->fetchColumn() > 0) {
        $emailError = "Email already exists!";
    }

    // Check if phone number already exists
    $phoneCheck = "SELECT COUNT(*) FROM users WHERE userPhone = :phone";
    $stmt = $conn->prepare($phoneCheck);
    $stmt->bindParam(':phone', $phone);
    $stmt->execute();
    if ($stmt->fetchColumn() > 0) {
        $phoneError = "Phone number already exists!";
    }

    if (isset($emailError) || isset($phoneError)) {
        // Display error messages and keep other form fields filled
        include 'regisForm.php'; 
        exit();
    }

    // Generate OTP and store it in session
    $otp = mt_rand(100000, 999999);
    $_SESSION['otp'] = $otp;
    $_SESSION['fname'] = $fname;
    $_SESSION['lname'] = $lname;
    $_SESSION['email'] = $email;
    $_SESSION['phone'] = $phone;
    $_SESSION['city'] = $city;
    $_SESSION['prov'] = $prov;
    $_SESSION['medcon'] = $medcon;
    $_SESSION['hashed_pass'] = $hashed_pass;

    // Email configuration
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';  // Specify SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = 'hansdc0203@gmail.com'; // SMTP username
    $mail->Password = 'izojelwy rgnr wutm'; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;   // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;  // TCP port to connect to

    $mail->setFrom('noreply@JPDC.com', 'Joy Pascual Dental Clinic');
    $mail->addAddress($email); // Add the user's email

    $mail->isHTML(true);  // Set email format to HTML
    $mail->Subject = 'Email Verification OTP';
    $mail->Body    = 'Your OTP for registration is: ' . $otp;

    try {
        $mail->send();
        // Redirect to OTP verification page
        header("Location: verifyOTP.php");
        exit();
    } catch (Exception $e) {
        echo 'Email could not be sent. Mailer Error: ', $mail->ErrorInfo;
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
