<?php
session_start();
require "adminConx.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

if (isset($_POST['logout'])) {
    // Destroy the session
    // Redirect to login form
    header("Location: index.php");
    session_destroy();
    exit;
}


// Simulated session user ID
$userId = $_SESSION['userID'];

// Query to check if there are confirmed appointments that are not yet completed
$sqlFetch = "SELECT COUNT(*) FROM booking WHERE bookConfirm = 'Confirmed' AND bookStatus = 'Not Done'";
$stmt = $conn->prepare($sqlFetch);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

// Get the count from the result
$bookingCount = $row['COUNT(*)'];

// Check if there are confirmed appointments that are yet to be completed
$hasConfirmedNotCompletedBookings = ($bookingCount > 0);

// Query to get total earnings per month for paid services
$sqlEarnings = "
    SELECT 
        DATE_FORMAT(b.bookDateTime, '%Y-%m') AS month, 
        SUM(s.servPrice) AS totalEarnings 
    FROM 
        booking b
    JOIN 
        services s ON b.servID = s.servID
    JOIN 
        payment p ON b.bookID = p.bookID
    WHERE 
        b.bookStatus = 'Done' AND 
        b.bookConfirm = 'Confirmed' AND 
        p.payStatus = 'Paid'
    GROUP BY 
        month 
    ORDER BY 
        month DESC
";

$stmtEarnings = $conn->prepare($sqlEarnings);
$stmtEarnings->execute();
$earningsData = $stmtEarnings->fetchAll(PDO::FETCH_ASSOC);

$months = [];
$totalEarnings = [];

foreach ($earningsData as $data) {
    $months[] = $data['month'];
    $totalEarnings[] = (float)$data['totalEarnings'];
}
$totalEarningsSum = array_sum($totalEarnings);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            height: 100vh;
            width: 250px;
            background-color: #419bc4;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 16px;
            text-decoration: none;
            text-align: left;
            font-size: 18px;
            position: relative; /* To position the ::before element */
        }

        .sidebar a:hover {
            background-color: #11566e;
        }

        .sidebar a.active {
            background-color: #11566e;
        }

        /* White rectangle for active menu item */
        .sidebar a.active::before {
            content: '';
            position: absolute;
            left: -15px; /* Adjust as needed */
            top: 0;
            bottom: 0;
            width: 10px; /* Width of the rectangle */
            background-color: white; /* Color of the rectangle */
            border-radius: 5px; /* Optional: rounded corners */
        }

        .content {
            margin-left: 250px;
            padding: 20px;
            background-color: #ffffff;
            min-height: 100vh;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .content h1, .content h2 {
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .logout-btn input {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 50px;
            height: 50px;
            width: 250px;
            transition: background-color 0.3s;
        }

        .logout-btn input:hover {
            background-color: #11566e;
        }

        /* Modal CSS */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 100px;
        }

        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
        }

        .modal-content h2 {
            color: #333;
            margin-bottom: 10px;
        }

        .modal-content h3 {
            color: #555;
        }

        .modal-content p a {
            color: #419bc4;
            text-decoration: underline;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }


        .profile-section {
            display: flex;
            align-items: center;
            padding: 20px;
            color: white;
        }

        .profile-section img {
            border-radius: 50%;
            width: 60px;
            height: 60px;
            margin-right: 10px;
        }

        .profile-section div {
            line-height: 1.5;
        }

        .profile-section div span {
            display: block;
        }

        .profile-section div span.email {
            font-size: 10px;
        }

        .logo {
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            width: 200px; /* Adjust as needed */
        }
        button {
            background-color: transparent; /* No background color */
            color: white; /* Text color */
            border: 2px solid white; /* White outline */
            cursor: pointer; /* Pointer cursor on hover */
            font-size: 16px; /* Font size */
            border-radius: 8px; /* Optional: rounded corners */
            transition: background-color 0.3s, color 0.3s; /* Smooth transition */
        }

        button:hover {
            background-color: white; /* Background color on hover */
            color: #419bc4; /* Change text color on hover */
        }
    </style>
</head>
<body>
    <?php
        $userID = $_SESSION['userID'];

        $sqlFetch = "SELECT * FROM users WHERE userID = :userID";
        $stmt = $conn->prepare($sqlFetch);
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>

    <div class="sidebar">
        <div class="profile-section">
            <img src="images/default_pic.png" alt="Admin Profile">
            <div>
                <?php if ($row) { ?>
                    <span><strong><?php echo htmlspecialchars($row['userFName'] . " " . $row['userLName']); ?></strong></span>
                    <span class="email"><?php echo htmlspecialchars($row['userEmail']); ?></span>
                <?php } ?>
            </div>
        </div>
        <a href="adminPage.php" class="active">Dashboard</a>
        <a href="adminAppointList.php">Appointments</a>
        <a href="adminServices.php">Services</a>
        <a href="adminUserList.php">User Profiles</a>
        <a href="adminAuditTrail.php">User Activity</a>
        <?php if ($row) { ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="logout-btn">
                    <input type="submit" name="logout" value="Logout">
                </form>
        <?php } ?>

        <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic" class="logo">
    </div>

    <div class="content">
 
        <div class="container">
            
            <h2>Total Earnings Per Month (Paid)</h2>
            <!-- Display Total Earnings -->
            <h3>Total Earnings: <?php echo number_format($totalEarningsSum, 2); ?> (in PHP)</h3>
            <canvas id="earningsChart" width="400" height="200"></canvas>
            
        </div>

        <?php if ($hasConfirmedNotCompletedBookings): ?>
            <div id="bookingModal" class="modal" style="display:block;">
                <div class="modal-content">
                    <span class="close">&times;</span>
                    <h2>Booking Notification</h2>
                    <h3><?php echo $bookingCount . " confirmed appointment(s) are yet to be completed."?></h3>
                    <p>Check <a href="adminAppointList.php">here</a>.</p>
                </div>
            </div>
        <?php endif; ?>

    </div>

    <script>
        // JavaScript to show the modal if there are confirmed appointments not done
        var isConfirmedNotCompleted = <?php echo json_encode($hasConfirmedNotCompletedBookings); ?>;

        if (isConfirmedNotCompleted) {
            var modal = document.getElementById("bookingModal");
            var span = document.getElementsByClassName("close")[0];

            modal.style.display = "block";

            // Close the modal when the user clicks on the close button (x)
            span.onclick = function() {
                modal.style.display = "none";
            }

            // Close the modal when the user clicks outside the modal
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        }

        const ctx = document.getElementById('earningsChart').getContext('2d');
            const earningsChart = new Chart(ctx, {
                type: 'bar', // Type of chart (bar, line, pie, etc.)
                data: {
                    labels: <?php echo json_encode($months); ?>, // Labels for the x-axis
                    datasets: [{
                        label: 'Total Earnings',
                        data: <?php echo json_encode($totalEarnings); ?>, // Data for the y-axis
                        backgroundColor: 'rgba(65, 155, 196, 0.6)', // Bar color
                        borderColor: 'rgba(65, 155, 196, 1)', // Border color
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Total Earnings (PHP)'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Month'
                            }
                        }
                    }
                }
            });

    </script>
</body>
</html>