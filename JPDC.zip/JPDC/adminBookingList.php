<?php
    session_start();

     // Check if the user is logged in and is an admin
    if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
        header("Location: loginForm.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Booking List</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
            background-image: url('images/homepagebg.avif');
            background-size: cover; /* Cover the entire body */
            background-position: center; /* Center the background image */
        }

        .container {
            max-width: 900px;
            margin: 30px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            text-align: center;
            color: #333;
            margin: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #000;
            color: white;
            font-weight: normal;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .back-button {
            display: block;
            width: fit-content;
            margin: 10px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background-color: #0056b3;
        }
        
        .month-group {
            margin-top: 30px;
        }

        .month-title {
            font-size: 24px;
            font-family: Georgia, 'Times New Roman', Times, serif;
            margin: 20px 0 10px;
            color: #0056b3;
            text-align: center;
        }

        .day-title {
            font-size: 18px;
            margin: 10px 0;
            color: #555;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="adminPage.php" method="post">
            <input type="submit" value="Back" class="back-button">
        </form>
        <h1>Today's Bookings</h1>
        <!-- Table displaying today's booking list -->
        <?php
        // Include the database connection file
        require "adminConx.php";

        try {
            // Get today's date
            $today = date('Y-m-d');

            // Prepare the SQL query to fetch bookings created today, using DATE() to compare only the date part
            $sql = "SELECT b.bookID, CONCAT(u.userFName, ' ', u.userLName) AS fullName, s.servName, s.servPrice, b.bookSched, b.bookTime
                    FROM booking b
                    INNER JOIN users u ON b.userID = u.userID
                    INNER JOIN services s ON b.servID = s.servID
                    WHERE DATE(b.bookDateTime) = :today";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':today', $today, PDO::PARAM_STR);
            $stmt->execute();

            // Check if there are bookings made today
            if ($stmt->rowCount() > 0) {
                // Fetch and display each booking
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<div class='month-group'>";
                    echo "<div class='month-title'>" . date('F Y', strtotime($row['bookSched'])) . "</div>";
                    echo "<div class='day-title'>" . date('l, F jS', strtotime($row['bookSched'])) . "</div>";
                    echo "<table>";
                    echo "<tr>";
                    echo "<th>Booking ID</th>";
                    echo "<th>Name</th>";
                    echo "<th>Service</th>";
                    echo "<th>Service Price</th>";
                    echo "<th>Slot Time</th>";
                    echo "</tr>";
                    echo "<tr>";
                    echo "<td>" . $row['bookID'] . "</td>";
                    echo "<td>" . $row['fullName'] . "</td>";
                    echo "<td>" . $row['servName'] . "</td>";
                    echo "<td>" . $row['servPrice'] . "</td>";
                    echo "<td>" . $row['bookTime'] . "</td>";
                    echo "</tr>";
                    echo "</table>";
                    echo "</div>";
                }
            } else {
                // Display a message if no bookings are found today
                echo "<p>No bookings found for today.</p>";
            }
        } catch (PDOException $e) {
            // Display error message if an exception occurs
            echo "<p>Error: " . $e->getMessage() . "</p>";
        }

        // Close the database connection
        $conn = null;
        ?>
    </div>
</body>
</html>
