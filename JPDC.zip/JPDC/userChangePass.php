<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to index.php
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - Joy Pascual Dental Clinic</title>
    
</head>
<body>
    <div class="container">
        <h1>Change Password</h1>
        <form method="post" action="userChangePassSubmit.php">
            <div class="form-group">
                <label for="oldPassword">Old Password:</label>
                <input type="password" id="oldPassword" name="oldPassword" required>
            </div>
            <div class="form-group">
                <label for="newPassword">New Password:</label>
                <input type="password" id="newPassword" name="newPassword" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Password must be at least 8 characters long, containing at least one uppercase letter, one lowercase letter, and one number">
            </div>
            <div class="form-group">
                <label for="confirmNewPassword">Confirm New Password:</label>
                <input type="password" id="confirmNewPassword" name="confirmNewPassword" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Password must be the same as New Password">
            </div>
            <!-- Error message -->
            <?php if (isset($_SESSION["error"]) && !empty($_SESSION["error"])) { ?>
                <div class="error-message"><?php echo $_SESSION["error"]; ?></div>
                <?php
                // Clear the error message from the session after displaying it
                unset($_SESSION["error"]);
                ?>
            <?php } ?>
            <input type="submit" name="changePassword" value="Change Password" class="btn btn-primary">
        </form>

        <div class="action-links">
            <a href="userPage.php">Back</a>
        </div>
    </div>
</body>
</html>
