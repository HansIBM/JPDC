<?php
// Include the database connection file
require "adminConx.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if bookID is set and not empty
    if (isset($_POST["bookID"]) && !empty($_POST["bookID"])) {
        $bookID = $_POST["bookID"];

        try {
            // Fetch the user ID associated with the booking ID
            $sqlUserID = "SELECT userID FROM booking WHERE bookID = :bookID";
            $stmtUserID = $conn->prepare($sqlUserID);
            $stmtUserID->bindParam(':bookID', $bookID);
            $stmtUserID->execute();
            $row = $stmtUserID->fetch(PDO::FETCH_ASSOC);
            $userID = $row['userID'];

            // Fetch the bookTime associated with the booking ID
            $sqlBookTime = "SELECT bookTime FROM booking WHERE bookID = :bookID";
            $stmtBookTime = $conn->prepare($sqlBookTime);
            $stmtBookTime->bindParam(':bookID', $bookID);
            $stmtBookTime->execute();
            $bookTimeRow = $stmtBookTime->fetch(PDO::FETCH_ASSOC);
            $bookTime = $bookTimeRow['bookTime'];

            // Update the booking status to "Cancelled" in the booking table
            $sqlCancel = "UPDATE booking SET bookCancel = 'Cancelled', bookStatus = 'Cancelled', bookSlotAvail = 'Yes' WHERE bookID = :bookID";
            $stmtCancel = $conn->prepare($sqlCancel);
            $stmtCancel->bindParam(':bookID', $bookID);
            $stmtCancel->execute();

            // Log the cancellation action in the audit trail
            $action = "Cancelled appointment for booking ID: $bookID. Date: " . date('l, F jS, Y') . ". Time: $bookTime";
            $auditDateTime = date("Y-m-d H:i:s");
            $sqlAudit = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, :action, :auditDateTime)";
            $stmtAudit = $conn->prepare($sqlAudit);
            $stmtAudit->bindParam(':userID', $userID);
            $stmtAudit->bindParam(':action', $action);
            $stmtAudit->bindParam(':auditDateTime', $auditDateTime);
            $stmtAudit->execute();

            // Redirect back to the admin page after cancellation
            header("Location: adminAppointList.php");
            exit;
        } catch (PDOException $e) {
            // Display error message if an exception occurs
            echo "Error: " . $e->getMessage();
        }
    } else {
        // Redirect back to the admin page if bookID is not set or empty
        header("Location: adminPage.php");
        exit;
    }
} else {
    // Redirect back to the admin page if the request method is not POST
    header("Location: adminPage.php");
    exit;
}

// Close the database connection
$conn = null;
?>
