<?php
session_start();
require "adminConx.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}

if (isset($_POST['logout'])) {
    // Destroy the session
    session_destroy();

    // Redirect to login form
    header("Location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>User Activity</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            height: 100vh;
            width: 250px;
            background-color: #419bc4;
            padding-top: 20px;
            position: fixed;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 16px;
            text-decoration: none;
            text-align: left;
            font-size: 18px;
            position: relative; /* To position the ::before element */
        }

        .sidebar a:hover {
            background-color: #11566e;
        }

        .sidebar a.active {
            background-color: #11566e;
        }

        /* White rectangle for active menu item */
        .sidebar a.active::before {
            content: '';
            position: absolute;
            left: -15px; /* Adjust as needed */
            top: 0;
            bottom: 0;
            width: 10px; /* Width of the rectangle */
            background-color: white; /* Color of the rectangle */
            border-radius: 5px; /* Optional: rounded corners */
        }

        .content {
            margin-left: 250px; /* Same as the sidebar width */
            padding: 30px 40px; /* Increased padding for better spacing */
            background-color: #f5f5f5; /* Subtle background color */
            min-height: 100vh; /* Ensure it fills the entire height */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Slightly larger shadow for more depth */
            border-radius: 10px; /* Rounded corners */
        }

        .content h1, .content h2 {
            color: #333;
            margin-bottom: 20px;
            font-family: 'Arial', sans-serif;
        }

        .add-button {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 10px 20px;
            width: 400px;
            margin-bottom: 30px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .add-button:hover {
            background-color: #11566e;
        }

        .center {
            text-align: center;
        }


        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            border-radius: 8px;
            overflow: hidden; /* To apply border-radius to the table */
        }

        table th, table td {
            padding: 12px; /* Increased padding for better spacing */
            border: 1px solid #ddd;
            text-align: left;
            background-color: #f9f9f9; /* Light background color for table rows */
        }

        table th {
            background-color: #419bc4; /* Header background color */
            color: white; /* Header text color */
            font-weight: bold;
            text-align: center; /* Center align headers */
        }

        table tbody tr:nth-child(even) {
            background-color: #f2f2f2; /* Alternate row coloring */
        }

        table tbody tr:hover {
            background-color: #e6f7ff; /* Row hover effect */
            cursor: pointer; /* Pointer cursor on hover */
        }

        .action-buttons form {
            display: inline-block; /* Align form buttons horizontally */
        }

        .action-buttons input {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 6px 12px; /* Adjusted padding for action buttons */
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .action-buttons input:hover {
            background-color: #11566e; /* Darken on hover */
        }


        .logout-btn input {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            margin-top: 50px;
            height: 50px;
            width: 250px;
            transition: background-color 0.3s;
        }

        .logout-btn input:hover {
            background-color: #11566e;
        }

        /* Modal CSS */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 100px;
        }

        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
        }

        .modal-content h2 {
            color: #333;
            margin-bottom: 10px;
        }

        .modal-content h3 {
            color: #555;
        }

        .modal-content p a {
            color: #419bc4;
            text-decoration: underline;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }


        .profile-section {
            display: flex;
            align-items: center;
            padding: 20px;
            color: white;
        }

        .profile-section img {
            border-radius: 50%;
            width: 60px;
            height: 60px;
            margin-right: 10px;
        }

        .profile-section div {
            line-height: 1.5;
        }

        .profile-section div span {
            display: block;
        }

        .profile-section div span.email {
            font-size: 10px;
        }

        .logo {
            position: absolute;
            bottom: 50px;
            left: 50%;
            transform: translateX(-50%);
            width: 200px; /* Adjust as needed */
        }
        button {
            background-color: transparent; /* No background color */
            color: white; /* Text color */
            border: 2px solid white; /* White outline */
            cursor: pointer; /* Pointer cursor on hover */
            font-size: 16px; /* Font size */
            border-radius: 8px; /* Optional: rounded corners */
            transition: background-color 0.3s, color 0.3s; /* Smooth transition */
        }

        button:hover {
            background-color: white; /* Background color on hover */
            color: #419bc4; /* Change text color on hover */
        }

        /* Date Grouping Styles (Month/Day Titles) */
        .month-group {
            margin-bottom: 30px;
        }

        .month-title {
            font-size: 24px;
            font-weight: bold;
            color: #419bc4;
            margin-bottom: 10px;
        }

        .day-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-top: 20px;
            margin-bottom: 10px;
        }

        /* Pagination Styling */
        .pagination-container {
            text-align: center;
            margin: 20px 0;
        }

        .pagination a, .pagination span {
            display: inline-block;
            padding: 10px 15px;
            margin: 0 5px;
            border-radius: 5px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            color: #333;
            text-decoration: none;
            font-size: 16px;
        }

        .pagination a:hover {
            background-color: #419bc4;
            color: white;
            border-color: #419bc4;
        }

        .pagination span {
            background-color: #419bc4;
            color: white;
            font-weight: bold;
        }

        /* PDF Download Button */
        .pdf-button {
            background-color: #419bc4;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            margin-bottom: 20px;
            transition: background-color 0.3s;
        }

        .pdf-button:hover {
            background-color: #11566e;
        }

    </style>
</head>
<body>
    <?php

        $userID = $_SESSION['userID'];

        $sqlFetch = "SELECT * FROM users WHERE userID = :userID";
        $stmt = $conn->prepare($sqlFetch);
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>

    <div class="sidebar">
        <div class="profile-section">
            <img src="images/default_pic.png" alt="Admin Profile">
            <div>
                <?php if ($row) { ?>
                    <span><strong><?php echo htmlspecialchars($row['userFName'] . " " . $row['userLName']); ?></strong></span>
                    <span class="email"><?php echo htmlspecialchars($row['userEmail']); ?></span>
                <?php } ?>
            </div>
        </div>
        <a href="adminPage.php" >Dashboard</a>
        <a href="adminAppointList.php">Appointments</a>
        <a href="adminServices.php" >Services</a>
        <a href="adminUserList.php">User Profiles</a>
        <a href="adminAuditTrail.php" class="active">User Activity</a>
        <?php if ($row) { ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="logout-btn">
                    <input type="submit" name="logout" value="Logout">
                </form>
        <?php } ?>

        <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic" class="logo">
    </div>

    <div class="content">
 
        <?php
           
            $userID = $_SESSION['userID'];

            // Pagination variables
            $limit = 30; // Number of rows per page
            $page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number

            // Calculate offset for SQL query
            $offset = ($page - 1) * $limit;

            // Prepare the SQL query to count total rows
            $sqlCount = "SELECT COUNT(*) AS total FROM audittrail";
            $stmt = $conn->prepare($sqlCount);
            $stmt->execute();
            $totalRows = $stmt->fetchColumn();
            $totalPages = ceil($totalRows / $limit);

            // Prepare the SQL query to fetch audit trail data
            $sqlFetch = "SELECT audittrail.*, users.userFName, users.userLName 
                        FROM audittrail
                        INNER JOIN users ON audittrail.userID = users.userID
                        ORDER BY audittrail.auditID DESC
                        LIMIT :limit OFFSET :offset"; // Add ORDER BY to sort by timestamp
            $stmt = $conn->prepare($sqlFetch);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
        ?>
        <div class="container">
            <h1>AUDIT TRAIL</h1>

                <form action="adminGenAuditTrail.php" method="post">
                    <input type="submit" value="Download PDF" class="pdf-button">
                </form>


            <!-- Pagination (above table) -->
            <div class="pagination-container">
                <div class="pagination">
                    <?php
                    // Previous page link
                    if ($page > 1) {
                        echo "<a href='adminAuditTrail.php?page=1'>&lt;&lt;</a>";
                        echo "<a href='adminAuditTrail.php?page=" . ($page - 1) . "'>&lt;</a>";
                    }

                    // Page number links
                    echo "<span>Page $page</span>";

                    // Next page link
                    if ($stmt->rowCount() == $limit) {
                        $next_page = $page + 1;
                        echo "<a href='adminAuditTrail.php?page=$next_page'>&gt;</a>";
                        // Link to the last page
                        echo "<a href='adminAuditTrail.php?page=$totalPages'>&gt;&gt;</a>";
                    }
                    ?>
                </div>
            </div>

            <!-- Display audit trail grouped by month and day -->
            <?php
            // Fetch all audit trail data
            $allData = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Group audit trail entries by month and day
            $groupedData = [];
            foreach ($allData as $entry) {
                $timestamp = strtotime($entry['auditDateTime']);
                $monthYear = date('F Y', $timestamp);
                $day = date('F j, Y', $timestamp);
                $groupedData[$monthYear][$day][] = $entry;
            }

            // Sort months in descending order
            krsort($groupedData);

            // Display grouped data
            foreach ($groupedData as $monthYear => $days) {
                echo "<div class='month-group'>";
                echo "<h2 class='month-title'>$monthYear</h2>";
                // Sort days in descending order
                krsort($days);
                foreach ($days as $day => $entries) {
                    echo "<h3 class='day-title'>$day</h3>";
                    echo "<table>";
                    echo "<tr><th>Audit ID</th><th>Name</th><th>Action</th><th>Timestamp</th></tr>";
                    foreach ($entries as $row) {
                        echo "<tr>";
                        echo "<td>{$row['auditID']}</td>";
                        echo "<td>{$row['userFName']} {$row['userLName']}</td>";
                        echo "<td>{$row['actions']}</td>";
                        echo "<td>{$row['auditDateTime']}</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                }
                echo "</div>";
            }
            ?>

            <!-- Pagination (below table) -->
            <div class="pagination-container">
                <div class="pagination">
                    <?php
                    // Previous page link
                    if ($page > 1) {
                        echo "<a href='adminAuditTrail.php?page=1'>&lt;&lt;</a>";
                        echo "<a href='adminAuditTrail.php?page=" . ($page - 1) . "'>&lt;</a>";
                    }

                    // Page number links
                    echo "<span>Page $page</span>";

                    // Next page link
                    if ($stmt->rowCount() == $limit) {
                        $next_page = $page + 1;
                        echo "<a href='adminAuditTrail.php?page=$next_page'>&gt;</a>";
                        // Link to the last page
                        echo "<a href='adminAuditTrail.php?page=$totalPages'>&gt;&gt;</a>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script>

    </script>
</body>
</html>
