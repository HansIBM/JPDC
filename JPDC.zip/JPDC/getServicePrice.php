<?php
// Include the database connection file
require "userConx.php";

if (isset($_POST['serviceID'])) {
    $serviceID = $_POST['serviceID'];

    // Prepare and execute the query to fetch the service price
    try {
        $sql = "SELECT servPrice FROM services WHERE servID = :servID";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':servID', $serviceID);
        $stmt->execute();
        $service = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($service) {
            echo json_encode(['price' => $service['servPrice']]);
        } else {
            echo json_encode(['price' => null]);
        }
    } catch (PDOException $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
}

$conn = null; // Close the PDO connection
?>
