<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Joy Pascual Dental Clinic</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="servicestyles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
<header>
<!-- COPY PASTE LAGI TO KASI SAME LANG NAV LINKS-->
<div class="header-container">
        <div class="logo">
            <img src="images/ToothJPDC.png" alt="Joy Pascual Dental Clinic">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php#about">About</a></li>
                <li class="dropdown">
                    <a href="javascript:void(0)" class="dropbtn">Services <i class ="fas fa-chevron-down" style = "font-size: 12px; margin-left:5px"></i></a>
                    <div class="dropdown-content">
                        <a href="model.php">Teeth Model</a>
                        <a href="guest_service1.php">Esthetic Dentistry</a>
                        <a href="guest_service2.php">Prosthodontic Treatment</a>
                        <a href="guest_service3.php">Orthodontic Treatment</a>
                        <a href="guest_service4.php">Teeth Extraction</a>
                    </div>
                </li>
                <li><a href="loginForm.php">Account</a></li>
            </ul>
        </nav>
        <a href="userBooking.php" class="appointment-btn">Book an Appointment</a>
    </div>
</header>

<!-- New Section for Video and Description -->
<section class="intro-section">
    <div class="intro-container">
        <iframe width="600" height="350" src="https://www.youtube.com/embed/VzuGFcK4lqY?si=9wWUuWDGwj0v52TP" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        <div class="intro-description">
            <h2>Esthetic Dentistry - Whitening</h2>
            <p>A cosmetic dental procedure designed to brighten and whiten teeth by removing stains and discoloration, enhancing the overall appearance of your smile.</p>
            <p>This treatment uses safe and effective whitening agents to achieve a radiant, long-lasting result, improving both confidence and dental aesthetics.</p>
            <a href="userBooking.php" class="make-appointment-btn">Make an Appointment</a>
        </div>
    </div>
</section>

<footer>
    <div class="footer-container">
        <div class="footer-column">
            <h3>Useful Links</h3>
            <a href="#">Home</a>
            <a href="#">About</a>
            <a href="#">Services</a>
        </div>
        <div class="footer-column">
            <h3>Contact Us</h3>
            <a href="#">Contact Form</a>
            <a href="#">FAQ</a>
        </div>
        <div class="footer-column newsletter">
            <h3>Newsletter</h3>
            <input type="email" placeholder="Enter your email">
            <button><b>Subscribe</b></button>
            <div class="social-links">
                <a href="#"><img src="images/FBLOGO.png" alt="Facebook"></a>
                <a href="#"><img src="images/IGLOGO.png" alt="Instagram"></a>
            </div>
            <p>Mobile: 0912-345-6789</p>
            <p>Email: jpdc@gmail.com</p>
        </div>
    </div>
    <div class="footer-bottom">
        <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic">
        <div class="footer-bottom-links">
            <a href="#">Contact Us</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
        </div>
        <p>All Rights Reserved ©2024 Joy Pascual Dental Clinic</p>
    </div>
</footer>
</body>
</html>