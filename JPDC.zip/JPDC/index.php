<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Joy Pascual Dental Clinic</title>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="images/ToothLogo.png" type="image/x-icon">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Mapbox CSS -->
    <link href="https://api.mapbox.com/mapbox-gl-js/v2.12.0/mapbox-gl.css" rel="stylesheet">
</head>
<body>
<header>
    <div class="header-container">
        <div class="logo">
            <img src="images/ToothJPDC.png" alt="Joy Pascual Dental Clinic">
        </div>
        <nav>
            <ul class="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="#about">About</a></li>
                <li class="dropdown">
                    <a href="javascript:void(0)" class="dropbtn">Services <i class ="fas fa-chevron-down" style = "font-size: 12px; margin-left:5px"></i></a>
                    <div class="dropdown-content">
                        <a href="model.php">3D Teeth Model</a>
                        <a href="guest_service1.php">Esthetic Dentistry</a>
                        <a href="guest_service2.php">Prosthodontic Treatment</a>
                        <a href="guest_service3.php">Orthodontic Treatment</a>
                        <a href="guest_service4.php">Teeth Extraction</a>
                    </div>
                </li>
                <li><a href="loginForm.php">Account</a></li>
            </ul>
        </nav>
        <a href="loginForm.php" class="appointment-btn">Book an Appointment</a>
    </div>
</header>


    <!-- Slideshow Section -->
    <div class="slideshow-container">
        <div class="slides fade">
            <div class="slide-content">
                <img src="images/1.png" class="slide-image" alt="Slide 1">
            </div>
        </div>
        <div class="slides fade">
            <div class="slide-content">
                <div class="slide-text1">
                    Your Path to Better Oral Health<br><em>Starts Here.</em><br><br>
                    <a href="loginForm.php" class="book-now-btn">
                        Book Now <i class="fas fa-arrow-right"></i>
                    </a>
                </div>    
                <img src="images/2.png" class="slide-image" alt="Slide 2">
            </div>
        </div>
        <div class="slides fade">
            <div class="slide-content">
                <div class="slide-text2">
                    Experience Quality Dental Care<br>
                    <p>Know our services offered to meet your dental needs</p><br>
                    <a href="#services" class="book-now-btn">
                        Check our Services <i class="fas fa-arrow-right"></i>
                    </a>
                </div>  
                <img src="images/3.png" class="slide-image" alt="Slide 3">
            </div>
        </div>
        <a class="prev" onclick="changeSlide(-1)">&#10094;</a>
        <a class="next" onclick="changeSlide(1)">&#10095;</a>
    </div>

    <section class="dental-services">
        <h2 class="abouth2">Your Trusted Partner in Dental Health</h2>
        <center>
        <p style="text-align:center" class="aboutp">At our clinic, we prioritize your dental health and well-being. Let us be your partner in achieving and maintaining a radiant smile!</p>
        </center>   
    </section>
        
        <center>
    <section class="content" id="about">
            <h2 class="abouth2">Meet the Dentists</h2>
        
            <div class="about-container">
                <img src="images/Dra1.png" alt="Dentist Image" class="dentist-image">
                <div class="about-text">
                    <h3>Dr. Josephine P. Pascual (Head Dentist)</h3>
                    <p>-Centro Escolar University Manila Alumna Batch 1986<br>
                    -Specialization: General Dentistry, Orthodontics, Prosthodontics

                </p>
                </div>
            </div>

            <div class="about-container">
                <img src="images/Dra2.png" alt="Dentist Image" class="dentist-image">
                <div class="about-text">
                    <h3>Dr. Franchesca P. Eusebio (Associate Dentist)</h3>
                    <p>-Centro Escolar University Manila Alumna Batch 2020<br>
                    -Specialization: General Dentistry, Orthodontics, Esthetics, Surgery

                    </p>
                </div>
            </div>

            <!-- Mapbox Map Container -->
            <h3>Visit Us</h3>
            <div id="map" style="width: 100%; height: 400px; border-radius: 10px;"></div>

        </section>
    </center>


    <section class="services" id="services">
        <h2 class="abouth2">Services</h2>
        <center><p class="aboutp">Here are the services we offer here at Joy Pascual Dental Clinic:</p></center>
        <div class="service-tiles">
            <div class="service-tile">
                <a href="guest_service1.php"><img src="images/whitening.jpg" alt="Esthetic Dentistry - Whitening" class="service-image"></a>
                <h3 class="service-title">Esthetic Dentistry - Whitening</h3>
            </div>
            <div class="service-tile">
                <a href="guest_service2.php"><img src="images/denture.jpg" alt="Prosthodontic Treatment - Dentures" class="service-image"></a>
                <h3 class="service-title">Prosthodontic Treatment - Dentures</h3>
            </div>
            <div class="service-tile">
                <a href="guest_service3.php"><img src="images/braces.jpg" alt="Orthodontic Treatment - Braces" class="service-image"></a>
                <h3 class="service-title">Orthodontic Treatment - Braces</h3>
            </div>
            <div class="service-tile">
                <a href="guest_service4.php"><img src="images/extraction.jpg" alt="Tooth Extraction" class="service-image"></a>
                <h3 class="service-title">Tooth Extraction</h3>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <div class="footer-container">
            <div class="footer-column">
                <h3>Useful Links</h3>
                <a href="#">Home</a>
                <a href="#">About</a>
                <a href="#">Services</a>
            </div>
            <div class="footer-column">
                <h3>Contact Us</h3>
                <a href="#">Contact Form</a>
                <a href="#">FAQ</a>
            </div>
            <div class="footer-column newsletter">
                <h3>Newsletter</h3>
                <input type="email" placeholder="Enter your email">
                <button><b>Subscribe</b></button>
                <div class="social-links">
                    <a href="#"><img src="images/FBLOGO.png" alt="Facebook"></a>
                    <a href="#"><img src="images/IGLOGO.png" alt="Instagram"></a>
                </div>
                <p>Mobile: 0912-345-6789</p>
                <p>Email: jpdc@gmail.com</p>
            </div>
        </div>
        <div class="footer-bottom">
            <img src="images/ToothJPDCWhite.png" alt="Joy Pascual Dental Clinic">
            <div class="footer-bottom-links">
                <a href="#">Contact Us</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms & Conditions</a>
            </div>
            <p>All Rights Reserved ©2024 Joy Pascual Dental Clinic</p>
        </div>
    </footer>

    <!-- Scripts for the slideshow and Mapbox -->
    <script src="https://api.mapbox.com/mapbox-gl-js/v2.12.0/mapbox-gl.js"></script>

    <script>
        // Initialize Mapbox
        mapboxgl.accessToken = 'pk.eyJ1IjoidGVyYXN1IiwiYSI6ImNtMnN1djd5djAxdW8ybHM5OGtkc2s1aTEifQ.EBMorPjNIkE-2j5Nkffb9A'; // Replace with your Mapbox access token
        const map = new mapboxgl.Map({
            container: 'map', // ID of the map container
            style: 'mapbox://styles/mapbox/satellite-streets-v11', // Satellite with streets
            center: [120.8217052828627, 14.82888286241328], // Coordinates for the clinic (adjust to actual location)
            zoom: 15 // Zoom level
        });

        // Add a marker at the clinic's location
        const el = document.createElement('div');
        el.className = 'custom-marker';
        el.style.backgroundImage = 'url(images/location.png)'; // Custom image
        el.style.width = '30px';
        el.style.height = '30px';

        // Create the popup
        const popup = new mapboxgl.Popup({ offset: 25 })
        .setHTML(`
            <div style="font-family: Arial, sans-serif; color: #333; text-align: center; width: 200px;">
                <h3 style="margin: 0; color: #2d8ecf;">Joy Pascual Dental Clinic</h3>
                <p style="margin: 5px 0;">Baranggay, Malolos, Bulacan<br>RRHC+GM Malolos, Bulacan</p>
                <p style="margin: 5px 0;"><strong>Phone:</strong> <a href="tel:09123456789" style="color: #2d8ecf; text-decoration: none;">0912-345-6789</a></p>
                <a href="loginForm.php" style="display: inline-block; margin-top: 10px; padding: 8px 12px; background-color: #2d8ecf; color: #fff; text-decoration: none; border-radius: 4px;">Book an Appointment</a>
            </div>
        `);

        // Attach the marker and the popup to the map
        new mapboxgl.Marker(el)
            .setLngLat([120.8217052828627, 14.82888286241328])
            .setPopup(popup) // Set the popup on the marker
            .addTo(map);

    </script>


    <script>      
        let slideIndex = 0;
        showSlides();

        function showSlides() {
            let slides = document.getElementsByClassName("slides");
            for (let i = 0; i < slides.length; i++) {
                slides[i].style.display = "none"; // Hide all slides
            }
            slideIndex++;
            if (slideIndex > slides.length) { slideIndex = 1 } // Reset to first slide
            slides[slideIndex - 1].style.display = "block"; // Show current slide
            setTimeout(showSlides, 3000); // Change slide every 3 seconds
        }

        function changeSlide(n) {
            slideIndex += n;
            if (slideIndex > document.getElementsByClassName("slides").length) { slideIndex = 1 }
            if (slideIndex < 1) { slideIndex = document.getElementsByClassName("slides").length }
            showSlidesManually();
        }

        function showSlidesManually() {
            let slides = document.getElementsByClassName("slides");
            for (let i = 0; i < slides.length; i++) {
                slides[i].style.display = "none"; // Hide all slides
            }
            slides[slideIndex - 1].style.display = "block"; // Show the current slide
        }
    </script>
</body>
</html>