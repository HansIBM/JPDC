<?php 
/* Start the session    old code incase an error happened in time slots
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to index.php
    header("Location: index.php");
    exit();
}

// Include the database connection file
require "userConx.php";

// Check if the date is provided
if (isset($_POST['appointment_date'])) {
    $selectedDate = $_POST['appointment_date'];

    // Query the database to check for booked time slots on the selected date using PDO
    try {
        $bookedSlotsQuery = "
            SELECT bookTime 
            FROM booking 
            WHERE DATE(bookSched) = :selectedDate 
            AND bookSlotAvail = 'Yes'
        ";
        $bookedSlotsStmt = $conn->prepare($bookedSlotsQuery);
        $bookedSlotsStmt->bindParam(':selectedDate', $selectedDate, PDO::PARAM_STR);
        $bookedSlotsStmt->execute();
        $bookedSlots = $bookedSlotsStmt->fetchAll(PDO::FETCH_COLUMN, 0);

        // All available time slots for the day
        $allSlots = array(
            "09:00 AM",
            "10:00 AM",
            "11:00 AM",
            "12:00 PM",
            "01:00 PM",
            "02:00 PM",
            "03:00 PM",
            "04:00 PM",
            "05:00 PM"
        );

        // Filter out booked slots from the list of available slots
        $timeSlots = array_diff($allSlots, $bookedSlots);

        // Return the available slots as JSON
        echo json_encode(array_values($timeSlots));
    } catch (PDOException $e) {
        echo json_encode([]);
    }
} else {
    echo json_encode([]);
}

$conn = null; // Close the PDO connection */
?>
