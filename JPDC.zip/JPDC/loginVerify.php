<?php
    session_start();

    require "userConx.php";

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sqlFetch = "SELECT * FROM users WHERE userEmail = :email";
    $stmt = $conn->prepare($sqlFetch);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if($row){
        $hashed_pass = $row['userPass'];   

        if(password_verify($password, $hashed_pass)){
            $_SESSION['userID'] = $row['userID'];
            $_SESSION['userLevel'] = $row['userLevel'];
            $userID = $_SESSION['userID'];

            if ($row['userLevel'] == 1) {
                header("Location: adminPage.php");
                exit();
            } else if ($row['userLevel'] == 2) {
                $insertAuditQuery = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, 'Logged In', NOW())";
                $stmt = $conn->prepare($insertAuditQuery);
                $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
                $stmt->execute();
                
                header("Location: userHomePage.php");
                exit();
            }
        }else {
            $_SESSION['login_error'] = true; // Set error message session
            header("Location: loginForm.php");
            exit();
        }
    }else {
        $_SESSION['login_error'] = true; // Set error message session
        header("Location: loginForm.php");
        exit();
    }
    $conn = null;
?>
