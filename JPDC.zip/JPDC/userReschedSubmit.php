<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    header("Location: index.php");
    exit(); // Ensure no further code is executed
}

// Include the database connection file
require "userConx.php";
require 'PHPMailer/vendor/autoload.php'; // Include PHPMailer autoload file

// Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Retrieve data from POST request
$userID = $_SESSION['userID'];
$bookID = $_POST['bookID'] ?? null;
$service = $_POST['service'] ?? null;
$appointmentDate = $_POST['appointment_date'] ?? null;
$timeSlot = $_POST['time_slot'] ?? null;

try {
    // Prepare an update statement
    $sqlUpdate = "UPDATE booking SET 
                    bookSched = :appointmentDate, 
                    bookTime = :timeSlot,
                    bookDateTime = NOW()  -- Update with the current datetime
                  WHERE bookID = :bookID";

    // Prepare the statement
    $stmt = $conn->prepare($sqlUpdate);
    
    // Bind parameters
    $stmt->bindParam(':appointmentDate', $appointmentDate);
    $stmt->bindParam(':timeSlot', $timeSlot);
    $stmt->bindParam(':bookID', $bookID);

    // Execute the statement
    $stmt->execute();

    // Fetch user email from the users table
    $userEmailQuery = "SELECT userEmail FROM users WHERE userID = :userID";
    $userEmailStmt = $conn->prepare($userEmailQuery);
    $userEmailStmt->bindParam(':userID', $userID, PDO::PARAM_INT);
    $userEmailStmt->execute();
    $userEmailResult = $userEmailStmt->fetch(PDO::FETCH_ASSOC);

    // Check if user email is retrieved
    if (!$userEmailResult) {
        throw new Exception("User email not found.");
    }

    $userEmail = $userEmailResult['userEmail'];

    // Send a confirmation email

    logAuditTrail($conn, $userID, "Rescheduled an appointment: $bookID. New Date and Time: $appointmentDate $timeSlot");

    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'hansdc0203@gmail.com'; // Your SMTP username
        $mail->Password   = 'izojelwy rgnr wutm'; // Your SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('noreply@JPDC.com', 'Joy Pascual Dental Clinic');
        $mail->addAddress($userEmail); // User's email

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Rescheduling of Appointment';
        $mail->Body    = 
            "Appointment Rescheduled! Here are the details:<br>" .
            "Book ID: $bookID<br>" .
            "Service: $service<br>" .
            "New Appointment Date: $appointmentDate<br>" .
            "New Appointment Time: $timeSlot<br>" .
            "Thank you for choosing our clinic.";

        // Send the email
        if (!$mail->send()) {
            throw new Exception("Mail could not be sent: {$mail->ErrorInfo}");
        }
        
        // Redirect or show a success message
        header("Location: userPage.php");
        exit(); // Ensure no further code is executed

    } catch (Exception $e) {
        error_log("Mailer Error: {$e->getMessage()}");
        echo "Could not send email. Please try again later.";
        exit();
    }

} catch (PDOException $e) {
    echo "Error updating record: " . htmlspecialchars($e->getMessage());
}

function logAuditTrail($conn, $userID, $action) {
    $sql = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, :action, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':userID', $userID);
    $stmt->bindParam(':action', $action);
    $stmt->execute();
}
?>
