<?php
session_start();
require "userConx.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['userID']) || $_SESSION['userLevel'] != 1) {
    header("Location: loginForm.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Add Services</title>
    <style>
        /* Your CSS styles here */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('images/appointmentBG.png');
            background-attachment: fixed;
            background-size: cover;
            background-repeat: no-repeat;
        }

        .container {
            max-width: 900px; /* Wider container for better layout */
            margin: 30px auto;
            padding: 20px;
            background-color: #ffffff; /* White background for clarity */
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #4A4A4A; /* Darker title color */
            margin: 20px 0;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] , .back-button{
            padding: 10px 20px;
            background-color: #419bc4;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"].sbmt {
            width: 200px;
        }

        input[type="submit"]:hover , .back-button:hover{
            background-color: #11566e;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="adminServices.php" method="post">
            <input type="submit" value="Back" class="back-button">
        </form>
        <h1>Add Service</h1>
        <form action="adminAddServicesSubmit.php" method="post">
            <label for="servName">Service Name:</label>
            <input type="text" name="servName" id="servName" required>
            <label for="servPrice">Service Price:</label>
            <input type="number" name="servPrice" id="servPrice" required>
            <input type="submit" name="addService" value="Add Service">
        </form>
    </div>
</body>
</html>
