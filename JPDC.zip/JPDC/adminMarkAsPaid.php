<?php
// Include the database connection file
session_start();
require "adminConx.php";
require 'PHPMailer/vendor/autoload.php'; // Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form fields are set
    if (isset($_POST['bookID'])) {
        // Get the bookID from the form
        $bookID = $_POST['bookID'];
        
        try {
            // Get the user ID associated with the booking
            $getUserID = "SELECT userID FROM booking WHERE bookID = :bookID";
            $stmtUserID = $conn->prepare($getUserID);
            $stmtUserID->bindParam(':bookID', $bookID);
            $stmtUserID->execute();
            $row = $stmtUserID->fetch(PDO::FETCH_ASSOC);
            $userID = $row['userID'];

            // Fetch the user's email
            $getUserEmail = "SELECT userEmail FROM users WHERE userID = :userID"; // Assuming userEmail is in users table
            $stmtUserEmail = $conn->prepare($getUserEmail);
            $stmtUserEmail->bindParam(':userID', $userID);
            $stmtUserEmail->execute();
            $userEmailRow = $stmtUserEmail->fetch(PDO::FETCH_ASSOC);
            $userEmail = $userEmailRow['userEmail'];

            // Get service details associated with the booking
            $getServiceDetails = "
                SELECT 
                    b.servID, 
                    s.servName, 
                    b.bookSched 
                FROM 
                    booking b 
                INNER JOIN 
                    services s ON b.servID = s.servID 
                WHERE 
                    b.bookID = :bookID";
            $stmtServiceDetails = $conn->prepare($getServiceDetails);
            $stmtServiceDetails->bindParam(':bookID', $bookID);
            $stmtServiceDetails->execute();
            $serviceDetails = $stmtServiceDetails->fetch(PDO::FETCH_ASSOC);

            if ($serviceDetails) {
                $servID = $serviceDetails['servID'];
                $servName = $serviceDetails['servName'];
                $serviceDate = $serviceDetails['bookSched'];
                $notes = "Completed successfully"; // Add any notes you wish
                $createdAt = date('Y-m-d H:i:s');

                // Insert payment record
                $payMethod = "CASH";
                $payStatus = "Paid";
                $payDateTime = date('Y-m-d H:i:s');
                $payRemBal = 0; // Assuming full payment, set remaining balance to 0
                $sqlUpdatePayment = "UPDATE payment SET payMethod = :payMethod, payStatus = :payStatus, payRemBal = :payRemBal, payDateTime = :payDateTime WHERE bookID = :bookID";
                $stmtPayment = $conn->prepare($sqlUpdatePayment);
                $stmtPayment->bindParam(':payMethod', $payMethod);
                $stmtPayment->bindParam(':payStatus', $payStatus);
                $stmtPayment->bindParam(':payRemBal', $payRemBal); // Make sure this variable is set correctly
                $stmtPayment->bindParam(':payDateTime', $payDateTime);
                $stmtPayment->bindParam(':bookID', $bookID); // Bind the bookID
                $stmtPayment->execute();

                // Update the booking status in the booking table
                $updateBooking = "UPDATE booking SET bookStatus = 'Done' WHERE bookID = :bookID";
                $stmtBooking = $conn->prepare($updateBooking);
                $stmtBooking->bindParam(':bookID', $bookID);
                $stmtBooking->execute();

                // Insert into services_done
                $insertServiceDone = "INSERT INTO services_done (userID, serviceID, serviceName, serviceDateDone, serviceNotes, serviceDateTime) VALUES (:userID, :serviceID, :serviceName, :serviceDateDone, :serviceNotes, NOW())";
                $stmtServiceDone = $conn->prepare($insertServiceDone);
                $stmtServiceDone->bindParam(':userID', $userID);
                $stmtServiceDone->bindParam(':serviceID', $servID);
                $stmtServiceDone->bindParam(':serviceName', $servName);
                $stmtServiceDone->bindParam(':serviceDateDone', $serviceDate);
                $stmtServiceDone->bindParam(':serviceNotes', $notes);
                $stmtServiceDone->execute();

                // Insert into the audit trail table
                $action = "Paid booking ID: $bookID through CASH. Date: " . date('l, F jS, Y') . ". Service: $servName, Scheduled Date: $serviceDate.";
                $insertAuditTrail = "INSERT INTO audittrail (userID, actions, auditDateTime) VALUES (:userID, :action, NOW())";
                $stmtAudit = $conn->prepare($insertAuditTrail);
                $stmtAudit->bindParam(':userID', $userID);
                $stmtAudit->bindParam(':action', $action);
                $stmtAudit->execute();

                // Send email notification
                if (!sendEmailReceipt($userEmail, $bookID, $payRemBal, $payStatus, $servName, $serviceDate)) {
                    echo "Error sending email receipt.";
                }

                // Redirect back to the appointment list with a success message
                header("Location: adminAppointList.php?message=Appointment marked as done.");
                exit();
            } else {
                echo "Error: Service details not found.";
            }
        } catch (PDOException $e) {
            // Display error message if an exception occurs
            echo "Error: " . $e->getMessage();
        }
    } else {
        // Redirect back to the admin page with an error message
        header("Location: adminAppointList.php?error=missing_fields");
        exit();
    }
} else {
    // Redirect back to the admin page if accessed directly
    header("Location: adminPage.php");
    exit();
}

// Function to send email receipt
function sendEmailReceipt($userEmail, $bookID, $payRemBal, $payStatus, $servName, $serviceDate) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'hansdc0203@gmail.com'; // Your SMTP username
        $mail->Password   = 'your_password_here'; // Your SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('noreply@JPDC.com', 'Joy Pascual Dental Clinic');
        $mail->addAddress($userEmail); // User's email

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Payment Receipt for Your Appointment';
        $mail->Body    = 
            "Thank you for your payment! Here are the details:<br>" .
            "Book ID: $bookID<br>" .
            "Service: $servName<br>" .
            "Scheduled Date: $serviceDate<br>" .
            "Payment Amount: ₱" . number_format(0, 2) . "<br>" . // Assuming full payment, adjust accordingly
            "New Remaining Balance: ₱" . number_format($payRemBal, 2) . "<br>" .
            "Payment Status: $payStatus<br>" .
            "Payment Method: CASH<br>" .
            "Date and Time: " . date("Y-m-d H:i:s") . "<br>" .
            "Thank you for choosing our clinic.";

        // Send the email
        return $mail->send();
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        return false;
    }
}

// Close the database connection
$conn = null;
?>
